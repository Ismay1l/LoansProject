//
//  CashLoanTableViewCell.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/6/22.
//

import Foundation
import UIKit

class ClashLoanTableViewCell: UITableViewCell {
    
    //MARK: - UI Elements
    private lazy var iconView: UIImageView = {
        let icon = UIImageView()
        icon.translatesAutoresizingMaskIntoConstraints = false
        return icon
    }()
    
    private lazy var headerLabel = createLabel(textColor: UIColor(red: 0.33, green: 0.33, blue: 0.33, alpha: 1.00), fontSize: 16, fontWeight: .regular)
    private lazy var secondaryLabel = createLabel(textColor: UIColor(red: 0.11, green: 0.11, blue: 0.11, alpha: 1.00), fontSize: 16, fontWeight: .regular)
    
    
    //MARK: - Parent Delegate
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
    }
    
    //MARK: Functions
    private func setupUI() {
        contentView.addSubview(iconView)
        contentView.addSubview(headerLabel)
        contentView.addSubview(secondaryLabel)
        
        NSLayoutConstraint.activate([
            iconView.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 20),
            iconView.centerYAnchor.constraint(equalTo: self.centerYAnchor),
            iconView.widthAnchor.constraint(equalToConstant: 40),
            iconView.heightAnchor.constraint(equalToConstant: 40),
            
            headerLabel.leftAnchor.constraint(equalTo: iconView.rightAnchor, constant: 16),
            headerLabel.topAnchor.constraint(equalTo: iconView.topAnchor),
            
            secondaryLabel.leftAnchor.constraint(equalTo: iconView.rightAnchor, constant: 16),
            secondaryLabel.bottomAnchor.constraint(equalTo: iconView.bottomAnchor)
        ])
    }
    
    func setUpCell(_ model: Introduction) {
        iconView.image = UIImage(named: model.icon)
        headerLabel.text = model.headerText
        secondaryLabel.text = model.secondaryText
    }
}
