//
//  ViewController.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/6/22.
//

import UIKit

class HomeVC: UIViewController {
    
    //MARK: - Variables
    private let homeVM = HomeVM()
   
    //MARK: - UI Elements
    private lazy var loanImageView: UIImageView = {
        let image = UIImageView(image: UIImage(named: "icon-loans"))
        image.translatesAutoresizingMaskIntoConstraints = false
        return image
    }()
    
    private lazy var mainTableView: UITableView = {
        let view = UITableView()
        view.backgroundColor = .white
        view.scrollsToTop = true
        view.showsVerticalScrollIndicator = false
        view.separatorStyle = .none
        view.isScrollEnabled = true
        
        view.register(ClashLoanTableViewCell.self, forCellReuseIdentifier: "\(ClashLoanTableViewCell.self)")
        view.dataSource = self
        view.delegate = self
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var applyButton = createButton(setTitle: "Apply", background: selectedButtonColor, setTitleColor: .white, cornerRadius: 8)

    //MARK: - Parent Delegate
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        setConstraints()
        applyButton.addTarget(self, action: #selector(didTapApply(_:)), for: .touchUpInside)
    }
    
    //MARK: - Functions
    private func setConstraints() {
        view.addSubview(loanImageView)
        view.addSubview(mainTableView)
        view.addSubview(applyButton)
        
        let safeArea = view.safeAreaLayoutGuide
        
        NSLayoutConstraint.activate([
            loanImageView.topAnchor.constraint(equalTo: safeArea.topAnchor, constant: 18),
            loanImageView.leftAnchor.constraint(equalTo: safeArea.leftAnchor, constant: 93),
            loanImageView.rightAnchor.constraint(equalTo: safeArea.rightAnchor, constant: -93),
            loanImageView.heightAnchor.constraint(equalToConstant: 140),
            
            mainTableView.leftAnchor.constraint(equalTo: safeArea.leftAnchor, constant: 0),
            mainTableView.rightAnchor.constraint(equalTo: safeArea.rightAnchor, constant: 0),
            mainTableView.topAnchor.constraint(equalTo: loanImageView.bottomAnchor, constant: 38),
            mainTableView.bottomAnchor.constraint(equalTo: applyButton.topAnchor, constant: -25),
            
            applyButton.leftAnchor.constraint(equalTo: safeArea.leftAnchor, constant: 16),
            applyButton.rightAnchor.constraint(equalTo: safeArea.rightAnchor, constant: -16),
            applyButton.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor, constant: -21),
            applyButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    @objc
    private func didTapApply(_ sender: UIButton) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            let alertVC =  AlertVC()
            alertVC.delegate = self
            alertVC.subTitle = "You have an existing loan in the bank. Do you want to pay?"
            alertVC.modalPresentationStyle = .overCurrentContext
            alertVC.modalTransitionStyle = .crossDissolve
            UIApplication.shared.keyWindow?.rootViewController?.present(alertVC, animated: true, completion: nil)
        }
    }
}

//MARK: - HomeVC Extension
extension HomeVC: UITableViewDataSource,
                  UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        homeVM.model.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "\(ClashLoanTableViewCell.self)", for: indexPath) as! ClashLoanTableViewCell
        let item = homeVM.model[indexPath.row]
        cell.setUpCell(item)
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        64
    }
}

extension HomeVC: CustomAlertDelegate {
    func noButtonPressed() {
        let loansHomeVC = LoansHomeVC()
        loansHomeVC.title = "Loan request"
        navigationController?.pushViewController(loansHomeVC, animated: true)
    }
    
    func yesButtonPressed() {
        let loansVC = LoansVC()
        loansVC.title = "Loans"
        navigationController?.pushViewController(loansVC, animated: true)
    }
}

