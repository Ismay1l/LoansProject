//
//  HomeVM.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/6/22.
//

import Foundation

class HomeVM {
    
    var model = [
        Introduction(icon: "icon-camera", headerText: "Maximum amount", secondaryText: "30 000"),
        Introduction(icon: "icon-calendar", headerText: "Maximum period", secondaryText: "59 month"),
        Introduction(icon: "icon-interest", headerText: "Interest rate", secondaryText: "Minimum 14%"),
        Introduction(icon: "icon-calendar", headerText: "Comission", secondaryText: "1%"),
        Introduction(icon: "icon-age-range", headerText: "Age range", secondaryText: "20-65"),
        Introduction(icon: "icon-wallet", headerText: "Minimal net income", secondaryText: "300"),
        Introduction(icon: "icon-experience", headerText: "Last place of work experience", secondaryText: "6 month")
    ]
}
