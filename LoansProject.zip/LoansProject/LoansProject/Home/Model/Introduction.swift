//
//  Loans.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/6/22.
//

import Foundation

struct Introduction {
    var icon: String
    var headerText: String
    var secondaryText: String
}
