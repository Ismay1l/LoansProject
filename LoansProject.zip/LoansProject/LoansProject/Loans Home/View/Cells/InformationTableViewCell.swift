//
//  InformationTableViewCell.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/9/22.
//

import Foundation
import UIKit

class InformationTableViewCell: UITableViewCell {
    
    //MARK: - UI Elements
    private lazy var titleLabel = createLabel(textColor: UIColor(red: 0.33, green: 0.33, blue: 0.33, alpha: 1.00), fontSize: 14, fontWeight: .regular)
    private lazy var detailLabel = createLabel(textColor: UIColor(red: 0.14, green: 0.12, blue: 0.13, alpha: 1.00), fontSize: 16, fontWeight: .regular)
    
    //MARK: - Parent Delegate
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
    }
    
    //MARK: Functions
    private func setupUI() {
        contentView.addSubview(titleLabel)
        contentView.addSubview(detailLabel)
        
        NSLayoutConstraint.activate([
            titleLabel.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 16),
            titleLabel.topAnchor.constraint(equalTo: self.topAnchor, constant: 10),
            
            detailLabel.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 16),
            detailLabel.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -10)
        ])
    }
    
    func setUpCell(_ model: LoanDetail) {
        titleLabel.text = model.title
        detailLabel.text = model.detail
    }
}
