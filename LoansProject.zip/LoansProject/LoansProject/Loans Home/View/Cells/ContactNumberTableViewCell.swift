//
//  ContactNumberTableViewCell.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/13/22.
//

import Foundation
import UIKit

class ContactNumberTableViewCell: UITableViewCell {
    
    //MARK: - UI Elements
    private lazy var containerView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 10
        view.layer.borderWidth = 1
        view.layer.borderColor = UIColor.systemGray6.cgColor
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var numberView: TextView = {
        let view = TextView()
        view.backgroundColor = .white
        view.brancTitleLabel.text = "Home phone number"
        view.brancTextField.tag = 2
        view.brancTextField.keyboardType = .numberPad
        view.brancTextField.text = "+994"
        view.clipsToBounds = true
        view.layer.borderWidth = 1
        view.layer.borderColor = UIColor.systemGray5.cgColor
        view.layer.cornerRadius = 10
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var relationshipView: TextView = {
        let view = TextView()
        view.backgroundColor = .white
        view.brancTitleLabel.text = "Relationship"
        view.brancTextField.placeholder = "Name and relatives"
        view.brancTextField.tag = 5
        view.brancTextField.keyboardType = .numberPad
        view.clipsToBounds = true
        view.layer.borderWidth = 1
        view.layer.borderColor = UIColor.systemGray5.cgColor
        view.layer.cornerRadius = 10
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    //MARK: - Parent Delegate
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
    }
    
    //MARK: Functions
    private func setupUI() {
        contentView.addSubview(containerView)
        containerView.addSubview(numberView)
        containerView.addSubview(relationshipView)
        
        NSLayoutConstraint.activate([
            containerView.topAnchor.constraint(equalTo: self.topAnchor, constant: 10),
            containerView.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 16),
            containerView.rightAnchor.constraint(equalTo: self.rightAnchor, constant: -16),
            containerView.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -10),
            
            numberView.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 16),
            numberView.leftAnchor.constraint(equalTo: containerView.leftAnchor, constant: 16),
            numberView.rightAnchor.constraint(equalTo: containerView.rightAnchor, constant: -16),
            numberView.heightAnchor.constraint(equalToConstant: 56),
            
            relationshipView.topAnchor.constraint(equalTo: numberView.bottomAnchor, constant: 16),
            relationshipView.leftAnchor.constraint(equalTo: containerView.leftAnchor, constant: 16),
            relationshipView.rightAnchor.constraint(equalTo: containerView.rightAnchor, constant: -16),
            relationshipView.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -16),
            relationshipView.heightAnchor.constraint(equalToConstant: 56)
        ])
    }
}

//MARK: - ContactNumberTableViewCell Extension
extension ContactNumberTableViewCell: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let aSet = NSCharacterSet(charactersIn:"0123456789").inverted
        let compSepByCharInSet = string.components(separatedBy: aSet)
        let numberFiltered = compSepByCharInSet.joined(separator: "")
        return string == numberFiltered
    }
}

class SignUpTextField: UITextField {
    
    let padding = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 5)
    
    override open func textRect(forBounds bounds: CGRect) -> CGRect {
        return bounds.inset(by: padding)
    }
    
    override open func placeholderRect(forBounds bounds: CGRect) -> CGRect {
        return bounds.inset(by: padding)
    }
    
    override open func editingRect(forBounds bounds: CGRect) -> CGRect {
        return bounds.inset(by: padding)
    }
    
    override func rightViewRect(forBounds bounds: CGRect) -> CGRect {
        return bounds.inset(by: UIEdgeInsets(top: 0, left: self.frame.size.width - 45, bottom: 0, right: 0))
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    required override init(frame: CGRect) {
        super.init(frame: frame)
    }
}
