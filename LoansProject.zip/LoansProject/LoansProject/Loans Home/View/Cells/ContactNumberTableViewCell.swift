//
//  ContactNumberTableViewCell.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/13/22.
//

import Foundation
import UIKit

protocol ContactNumberTableViewCellDelegate: AnyObject {
    func didEnterText()
}

class ContactNumberTableViewCell: UITableViewCell {
    
    weak var delegate: ContactNumberTableViewCellDelegate?
    
    //MARK: - UI Elements
    private lazy var containerView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 10
        view.layer.borderWidth = 1
        view.layer.borderColor = UIColor.systemGray6.cgColor
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    lazy var numberView: TextView = {
        let view = TextView()
        view.backgroundColor = .white
        view.brancTitleLabel.text = "Home phone number"
        view.brancTextField.tag = 2
        view.brancTextField.keyboardType = .numberPad
        view.brancTextField.text = "+994"
        view.clipsToBounds = true
        view.layer.borderWidth = 1
        view.layer.borderColor = UIColor.systemGray5.cgColor
        view.layer.cornerRadius = 10
        view.brancTextField.addTarget(self, action: #selector(didEnterText(_:)), for: .editingDidEnd)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    lazy var relationshipView: TextView = {
        let view = TextView()
        view.backgroundColor = .white
        view.brancTitleLabel.text = "Relationship"
        view.brancTextField.placeholder = "Name and relatives"
        view.brancTextField.tag = 5
        view.brancTextField.keyboardType = .numberPad
        view.clipsToBounds = true
        view.layer.borderWidth = 1
        view.layer.borderColor = UIColor.systemGray5.cgColor
        view.layer.cornerRadius = 10
        view.brancTextField.addTarget(self, action: #selector(didEnterText(_:)), for: .editingDidEnd)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    //MARK: - Parent Delegate
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
    }
    
    //MARK: Functions
    private func setupUI() {
        contentView.addSubview(containerView)
        containerView.addSubview(numberView)
        containerView.addSubview(relationshipView)
        
        NSLayoutConstraint.activate([
            containerView.topAnchor.constraint(equalTo: self.topAnchor, constant: 10),
            containerView.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 16),
            containerView.rightAnchor.constraint(equalTo: self.rightAnchor, constant: -16),
            containerView.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -10),
            
            numberView.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 16),
            numberView.leftAnchor.constraint(equalTo: containerView.leftAnchor, constant: 16),
            numberView.rightAnchor.constraint(equalTo: containerView.rightAnchor, constant: -16),
            numberView.heightAnchor.constraint(equalToConstant: 56),
            
            relationshipView.topAnchor.constraint(equalTo: numberView.bottomAnchor, constant: 16),
            relationshipView.leftAnchor.constraint(equalTo: containerView.leftAnchor, constant: 16),
            relationshipView.rightAnchor.constraint(equalTo: containerView.rightAnchor, constant: -16),
            relationshipView.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -16),
            relationshipView.heightAnchor.constraint(equalToConstant: 56)
        ])
    }
    
    @objc
    private func didEnterText(_ field: UITextField) {
        if !field.hasText && field.text == "+994" {
            if field.text != "" && field.text != "+994" {
                delegate?.didEnterText()
            }
        }
    }
}
