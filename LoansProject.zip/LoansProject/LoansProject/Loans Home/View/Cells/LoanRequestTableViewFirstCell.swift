//
//  LoanRequestTableViewFirstCell.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/13/22.
//

import Foundation
import UIKit

class LoanRequestTableViewFirstCell: UITableViewCell {
    
    //MARK: - Variables
    private let rejectedLabelTextColor = UIColor(red: 0.94, green: 0.27, blue: 0.22, alpha: 1.00)
    private let rejectedLabelBackgroundColor = UIColor(red: 1.00, green: 0.95, blue: 0.95, alpha: 1.00)
    
    private let offerLabelTextColor = UIColor(red: 0.07, green: 0.72, blue: 0.42, alpha: 1.00)
    private let offerLabelBackgroundColor = UIColor(red: 0.93, green: 0.99, blue: 0.95, alpha: 1.00)
    
    private let labelColor = UIColor(red: 0.28, green: 0.30, blue: 0.33, alpha: 1.00)
    
    //MARK: - UI Elements
    private lazy var icon: UIImageView = {
        let icon = UIImageView(image: UIImage(named: "icon-pen"))
        icon.translatesAutoresizingMaskIntoConstraints = false
        return icon
    }()
    
    private lazy var requestLabel = createLabel(textColor: labelColor, fontSize: 14, fontWeight: .regular)
    private lazy var amountLabel = createLabel(textColor: labelColor, fontSize: 14, fontWeight: .regular)
    private lazy var stateLabel = createLabel(textColor: .white, fontSize: 14, fontWeight: .regular)
    
    //MARK: - Parent Delegate
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
        setUIElements()
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
    }
    
    //MARK: Functions
    private func setupUI() {
        contentView.addSubview(icon)
        contentView.addSubview(requestLabel)
        contentView.addSubview(amountLabel)
        contentView.addSubview(stateLabel)
        
        NSLayoutConstraint.activate([
            icon.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 19),
            icon.centerYAnchor.constraint(equalTo: self.centerYAnchor),
            
            requestLabel.leftAnchor.constraint(equalTo: icon.rightAnchor, constant: 19),
            requestLabel.topAnchor.constraint(equalTo: self.topAnchor, constant: 12),
            
            amountLabel.leftAnchor.constraint(equalTo: icon.rightAnchor, constant: 19),
            amountLabel.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -12),
            
            stateLabel.rightAnchor.constraint(equalTo: self.rightAnchor, constant: -16),
            stateLabel.centerYAnchor.constraint(equalTo: self.centerYAnchor),
            stateLabel.widthAnchor.constraint(equalToConstant: 70),
            stateLabel.heightAnchor.constraint(equalToConstant: 22)
        ])
    }
    
    private func setUIElements() {
        requestLabel.text = "Your request"
        stateLabel.layer.cornerRadius = 6
        stateLabel.clipsToBounds = true
        stateLabel.textAlignment = .center
        stateLabel.sizeToFit()
    }
    
    func setUpCell(_ model: LoanRequest) {
        requestLabel.text = model.title
        amountLabel.text = "\(Int(model.amount)) - \(model.duration) month"
        configureStateLabel(model.state)
    }
    
    private func configureStateLabel(_ state: Bool) {
        state ? setStateLabel(text: "Offer", textColor: offerLabelTextColor, backgroundColor: offerLabelBackgroundColor) :  setStateLabel(text: "Rejected", textColor: rejectedLabelTextColor, backgroundColor: rejectedLabelBackgroundColor)
    }
    
    private func setStateLabel(text: String, textColor: UIColor, backgroundColor: UIColor) {
        stateLabel.text = text
        stateLabel.textColor = textColor
        stateLabel.backgroundColor = backgroundColor
    }
}
