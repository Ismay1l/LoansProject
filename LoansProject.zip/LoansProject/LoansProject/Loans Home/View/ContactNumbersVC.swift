//
//  ContactNumbersVC.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/13/22.
//

import UIKit

class ContactNumbersVC: UIViewController {
    
    //MARK: - UI Elements
    private lazy var headerView: WarningView = {
        let view = WarningView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var contactNumberTableView: UITableView = {
        let view = UITableView()
        view.backgroundColor = .white
        view.scrollsToTop = true
        view.showsVerticalScrollIndicator = false
        view.separatorStyle = .none
        view.isScrollEnabled = false
        
        view.register(ContactNumberTableViewCell.self, forCellReuseIdentifier: "\(ContactNumberTableViewCell.self)")
        view.dataSource = self
        view.delegate = self
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var nextButton: UIButton = {
        let button = UIButton()
        button.setTitle("Next", for: .normal)
        button.backgroundColor = UIColor(red: 0.89, green: 0.89, blue: 0.89, alpha: 1.00)
        button.setTitleColor(UIColor.white, for: .normal)
        button.layer.cornerRadius = 8
        button.addTarget(self, action: #selector(didTapNext(_:)), for: .touchUpInside)
        button.isEnabled = true
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    //MARK: - Parent Delegate
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        setBackButton()
        setConstraints()
    }
    
    //MARK: - Functions
    private func setBackButton() {
        let yourBackImage = UIImage(named:"icon-back")
        navigationItem.backButtonTitle = ""
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: yourBackImage, style: .plain, target: self, action: #selector(popToPrevious(_:)))
        navigationController?.navigationBar.tintColor = UIColor(red: 0.22, green: 0.22, blue: 0.22, alpha: 1.00)
        navigationItem.largeTitleDisplayMode = .never
    }
    
    private func setConstraints() {
        view.addSubview(headerView)
        view.addSubview(contactNumberTableView)
        view.addSubview(nextButton)
        
        let safeArea = view.safeAreaLayoutGuide
        
        NSLayoutConstraint.activate([
            headerView.topAnchor.constraint(equalTo: safeArea.topAnchor, constant: 20),
            headerView.leftAnchor.constraint(equalTo: safeArea.leftAnchor, constant: 16),
            headerView.rightAnchor.constraint(equalTo: safeArea.rightAnchor, constant: -16),
            headerView.heightAnchor.constraint(equalToConstant: 24),
            
            contactNumberTableView.topAnchor.constraint(equalTo: headerView.bottomAnchor, constant: 20),
            contactNumberTableView.leftAnchor.constraint(equalTo: safeArea.leftAnchor, constant: 0),
            contactNumberTableView.rightAnchor.constraint(equalTo: safeArea.rightAnchor, constant: -0),
            contactNumberTableView.bottomAnchor.constraint(equalTo: nextButton.topAnchor, constant: -10),
            
            nextButton.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor, constant: -20),
            nextButton.leftAnchor.constraint(equalTo: safeArea.leftAnchor, constant: 16),
            nextButton.rightAnchor.constraint(equalTo: safeArea.rightAnchor, constant: -16),
            nextButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    @objc
    private func didTapNext(_ sender: UIButton) {
        let transferVC = TransferVC()
        transferVC.title = "Loan request"
        navigationController?.pushViewController(transferVC, animated: true)
    }
    
    @objc
    private func popToPrevious(_ sender: UIBarButtonItem) {
        navigationController?.backToViewController(viewController: LoanRequestVC.self)
    }
}

//MARK: - ContactNUmbersVC Extension
extension ContactNumbersVC: UITableViewDelegate,
                            UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "\(ContactNumberTableViewCell.self)", for: indexPath)
        cell.backgroundColor = .white
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        180
    }
}



