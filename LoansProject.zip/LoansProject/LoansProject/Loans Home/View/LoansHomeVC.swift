//
//  LoansHomeVC.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/9/22.
//

import UIKit

class LoansHomeVC: UIViewController {
    
    //MARK: - Variables
    private var loanRequestCount = 4
    private var informationCount = 6
    
    private let loanHomeVM = LoanHomeVM()
    
    //MARK: - UI Elements
    private lazy var mainScrollView: UIScrollView = {
        let view = UIScrollView()
        view.bounces = true
        view.alwaysBounceVertical = true
        view.isScrollEnabled = true
        view.scrollsToTop = true
        view.indicatorStyle = .default
        view.showsVerticalScrollIndicator = false
        view.backgroundColor = .clear
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var loanRequestTableView: UITableView = {
        let view = UITableView()
        view.backgroundColor = .white
        view.scrollsToTop = true
        view.showsVerticalScrollIndicator = false
        view.separatorStyle = .singleLine
        view.isScrollEnabled = false
        
        view.register(LoanRequestTableViewCell.self, forCellReuseIdentifier: "\(LoanRequestTableViewCell.self)")
        view.register(LoanRequestTableViewFirstCell.self, forCellReuseIdentifier: "\(LoanRequestTableViewFirstCell.self)")
        view.dataSource = self
        view.delegate = self
        view.estimatedRowHeight = 66
        view.rowHeight = UITableView.automaticDimension
        view.allowsMultipleSelection = false
        view.allowsSelection = true
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var informationTableView: UITableView = {
        let view = UITableView()
        view.backgroundColor = .white
        view.scrollsToTop = true
        view.showsVerticalScrollIndicator = false
        view.separatorStyle = .singleLine
        view.isScrollEnabled = false
        
        view.register(InformationTableViewCell.self, forCellReuseIdentifier: "\(InformationTableViewCell.self)")
        view.dataSource = self
        view.delegate = self
        view.estimatedRowHeight = 58
        view.rowHeight = UITableView.automaticDimension
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var buttonStackView: UIStackView = {
        let view = UIStackView()
        view.axis = .vertical
        view.distribution = .equalSpacing
        view.alignment = .leading
        view.isBaselineRelativeArrangement = false
        view.spacing = 16
        view.backgroundColor = .white
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var acceptButton: UIButton = {
        let button = UIButton()
        button.setTitle("Accept", for: .normal)
        button.backgroundColor = UIColor(red: 1.00, green: 0.71, blue: 0.00, alpha: 1.00)
        button.setTitleColor(UIColor.white, for: .normal)
        button.layer.cornerRadius = 8
        button.addTarget(self, action: #selector(didTapButton(_:)), for: .touchUpInside)
        button.tag = 1
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private lazy var cancelButton: UIButton = {
        let button = UIButton()
        button.setTitle("Cancel", for: .normal)
        button.backgroundColor = UIColor(red: 0.96, green: 0.96, blue: 0.96, alpha: 1.00)
        button.setTitleColor(UIColor(red: 1.00, green: 0.71, blue: 0.00, alpha: 1.00), for: .normal)
        button.layer.cornerRadius = 8
        button.addTarget(self, action: #selector(didTapButton(_:)), for: .touchUpInside)
        button.tag = 2
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private lazy var generalInfoLabel: UILabel = {
        let label = UILabel()
        label.text = "General information"
        label.font = .systemFont(ofSize: 18, weight: .semibold)
        label.textColor = UIColor(red: 0.14, green: 0.12, blue: 0.13, alpha: 1.00)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    //MARK: - Parent Delegate
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        setConstraints()
        setBackButton()
    }
    
    //MARK: - Functions
    private func setBackButton() {
        let yourBackImage = UIImage(named:"icon-back")
        navigationItem.backButtonTitle = ""
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: yourBackImage, style: .plain, target: self, action: #selector(popToPrevious(_:)))
        navigationController?.navigationBar.tintColor = UIColor(red: 0.22, green: 0.22, blue: 0.22, alpha: 1.00)
        navigationItem.largeTitleDisplayMode = .never
    }
    
    private func setConstraints() {
        view.addSubview(mainScrollView)
        mainScrollView.addSubview(loanRequestTableView)
        mainScrollView.addSubview(generalInfoLabel)
        mainScrollView.addSubview(informationTableView)
        mainScrollView.addSubview(buttonStackView)
        
        buttonStackView.addArrangedSubview(acceptButton)
        buttonStackView.addArrangedSubview(cancelButton)
        
        NSLayoutConstraint.activate([
            mainScrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            mainScrollView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -10),
            mainScrollView.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor),
            mainScrollView.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor),
            mainScrollView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            loanRequestTableView.leftAnchor.constraint(equalTo: mainScrollView.contentLayoutGuide.leftAnchor),
            loanRequestTableView.topAnchor.constraint(equalTo: mainScrollView.contentLayoutGuide.topAnchor),
            loanRequestTableView.rightAnchor.constraint(equalTo: mainScrollView.contentLayoutGuide.rightAnchor),
            loanRequestTableView.heightAnchor.constraint(equalToConstant: CGFloat(66 * loanRequestCount)),
            loanRequestTableView.centerXAnchor.constraint(equalTo: mainScrollView.centerXAnchor),
            
            generalInfoLabel.leftAnchor.constraint(equalTo: mainScrollView.contentLayoutGuide.leftAnchor, constant: 16),
            generalInfoLabel.topAnchor.constraint(equalTo: loanRequestTableView.bottomAnchor, constant: 24),
            
            informationTableView.topAnchor.constraint(equalTo: generalInfoLabel.bottomAnchor, constant: 8),
            informationTableView.leftAnchor.constraint(equalTo: mainScrollView.contentLayoutGuide.leftAnchor),
            informationTableView.rightAnchor.constraint(equalTo: mainScrollView.contentLayoutGuide.rightAnchor),
            informationTableView.heightAnchor.constraint(equalToConstant: CGFloat(58 * informationCount)),
            informationTableView.centerXAnchor.constraint(equalTo: mainScrollView.centerXAnchor),
            
            buttonStackView.topAnchor.constraint(equalTo: informationTableView.bottomAnchor, constant: 22),
            buttonStackView.leftAnchor.constraint(equalTo: mainScrollView.contentLayoutGuide.leftAnchor),
            buttonStackView.rightAnchor.constraint(equalTo: mainScrollView.contentLayoutGuide.rightAnchor),
            buttonStackView.centerXAnchor.constraint(equalTo: mainScrollView.centerXAnchor),
            buttonStackView.bottomAnchor.constraint(equalTo: mainScrollView.bottomAnchor, constant: 0),
            
            acceptButton.heightAnchor.constraint(equalToConstant: 50),
            acceptButton.leftAnchor.constraint(equalTo: buttonStackView.leftAnchor, constant: 16),
            acceptButton.rightAnchor.constraint(equalTo: buttonStackView.rightAnchor, constant: -16),
            
            cancelButton.heightAnchor.constraint(equalToConstant: 50),
            cancelButton.leftAnchor.constraint(equalTo: buttonStackView.leftAnchor, constant: 16),
            cancelButton.rightAnchor.constraint(equalTo: buttonStackView.rightAnchor, constant: -16)
        ])
    }
    
    @objc
    private func popToPrevious(_ sender: UIBarButtonItem) {
        navigationController?.backToViewController(viewController: HomeVC.self)
    }
    
    @objc
    private func didTapButton(_ sender: UIButton) {
        switch sender.tag {
        case 1:
            let contactNumbersVC = ContactNumbersVC()
            contactNumbersVC.title = "Loan Request"
            navigationController?.pushViewController(contactNumbersVC, animated: true)
        case 2:
            navigationController?.backToViewController(viewController: HomeVC.self)
        default:
            assertionFailure("This case shouldn't be called!")
        }
    }
}

//MARK: - LoansHomeVC Extension
extension LoansHomeVC: UITableViewDataSource,
                       UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == loanRequestTableView {
            return loanRequestCount
        }
        return informationCount
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == loanRequestTableView {
            if indexPath.row == 0 {
                let cell = tableView.dequeueReusableCell(withIdentifier: "\(LoanRequestTableViewFirstCell.self)", for: indexPath) as! LoanRequestTableViewFirstCell
                cell.selectionStyle = .none
                cell.setUpCell(loanHomeVM.firstCellModel)
                return cell
            } else {
                let cell = tableView.dequeueReusableCell(withIdentifier: "\(LoanRequestTableViewCell.self)", for: indexPath) as! LoanRequestTableViewCell
                cell.selectionStyle = .none
                let model = loanHomeVM.loeanRequestModel[indexPath.row - 1]
                cell.setUpCell(model)
                return cell
            }
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "\(InformationTableViewCell.self)", for: indexPath) as! InformationTableViewCell
            cell.selectionStyle = .none
            let model = loanHomeVM.detailModel[indexPath.row]
            cell.setUpCell(model)
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == loanRequestTableView {
            return 66
        }
        return 58
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == loanRequestTableView {
            if indexPath.row != 0 {
                let cell = tableView.cellForRow(at: indexPath) as! LoanRequestTableViewCell
                cell.setIcon(cell.isCellSelected)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        if tableView == loanRequestTableView {
            if indexPath.row != 0 {
                let cell = tableView.cellForRow(at: indexPath) as! LoanRequestTableViewCell
                cell.setIcon(cell.isCellSelected)
            }
        }
    }
}
