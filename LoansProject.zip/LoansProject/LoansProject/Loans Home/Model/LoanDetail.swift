//
//  LoanDetail.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/13/22.
//

import Foundation

struct LoanDetail {
    var title: String
    var detail: String
}
