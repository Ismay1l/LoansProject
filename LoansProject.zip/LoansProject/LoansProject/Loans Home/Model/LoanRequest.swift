//
//  LoanRequest.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/13/22.
//

import Foundation

struct LoanRequest {
    var amount: Double
    var duration: Int
    var state: Bool
    var title: String
}
