//
//  LoanHomeVM.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/13/22.
//

import Foundation

class LoanHomeVM {
    
    var firstCellModel = LoanRequest(amount: 3000, duration: 12, state: false, title: "Your request")
    
    var loeanRequestModel: [LoanRequest] = [
        LoanRequest(amount: 2000, duration: 12, state: true, title: "Bank purposal by month"),
        LoanRequest(amount: 3000, duration: 18, state: true, title: "Bank purposal by amount"),
        LoanRequest(amount: 6000, duration: 36, state: true, title: "Bank max proposal")
    ]
    
    var detailModel: [LoanDetail] = [
        LoanDetail(title: "Amount", detail: "6000 AZN"),
        LoanDetail(title: "Term", detail: "36 month"),
        LoanDetail(title: "Annual interest rate", detail: "18% "),
        LoanDetail(title: "Comission", detail: "1%"),
        LoanDetail(title: "Payment", detail: "217,67 AZN"),
        LoanDetail(title: "FIFD", detail: "19.03%")
    ]
}
