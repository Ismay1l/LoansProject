//
//  TransferVC.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/14/22.
//

import UIKit

class TransferVC: UIViewController {
    
    //MARK: - Variables
    private let transferVM = TransferVM()
    private var isCellSelected = false
    
    //MARK: - UI Elements
    private lazy var headerLabel = createLabel(textColor: .black, fontSize: 18, fontWeight: .regular)
    
    private lazy var methodsTableView: UITableView = {
        let view = UITableView()
        view.backgroundColor = .white
        view.scrollsToTop = true
        view.showsVerticalScrollIndicator = false
        view.separatorStyle = .none
        view.isScrollEnabled = true
        
        view.register(MethodsTableViewCell.self, forCellReuseIdentifier: "\(MethodsTableViewCell.self)")
        view.dataSource = self
        view.delegate = self
        view.allowsMultipleSelection = false
        view.allowsSelection = true
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var nextButton = createButton(setTitle: "Next", background: unselectedButtonColor, setTitleColor: .white, cornerRadius: 8)
    
    //MARK: - Parent Delegate
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        setConstraints()
        setBackButton()
        setUIElements()
    }
    
    //MARK: - Functions
    private func setConstraints() {
        view.addSubview(headerLabel)
        view.addSubview(methodsTableView)
        view.addSubview(nextButton)
        
        NSLayoutConstraint.activate([
            headerLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 25),
            headerLabel.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 16),
            
            methodsTableView.topAnchor.constraint(equalTo: headerLabel.bottomAnchor, constant: 24),
            methodsTableView.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor),
            methodsTableView.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor),
            methodsTableView.bottomAnchor.constraint(equalTo: nextButton.bottomAnchor, constant: -10),
            
            nextButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            nextButton.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 16),
            nextButton.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor, constant: -16),
            nextButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    private func setUIElements() {
        headerLabel.text = "Select the transfer method"
        nextButton.addTarget(self, action: #selector(didTapNext(_:)), for: .touchUpInside)
        nextButton.isEnabled = false
    }
    
    private func setBackButton() {
        let yourBackImage = UIImage(named:"icon-back")
        navigationItem.backButtonTitle = ""
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: yourBackImage, style: .plain, target: self, action: #selector(popToPrevious(_:)))
        navigationController?.navigationBar.tintColor = UIColor(red: 0.22, green: 0.22, blue: 0.22, alpha: 1.00)
        navigationItem.largeTitleDisplayMode = .never
    }
    
    @objc
    private func didTapNext(_ sender: UIButton) {
        let documentVC = DocumentsVC()
        documentVC.title = "Loan request"
        navigationController?.pushViewController(documentVC, animated: true)
    }
    
    @objc
    private func popToPrevious(_ sender: UIBarButtonItem) {
        navigationController?.popViewController(animated: true)
    }
}

//MARK: - TransferVC Extension
extension TransferVC: UITableViewDelegate,
                      UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        transferVM.transferMethodModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "\(MethodsTableViewCell.self)", for: indexPath) as! MethodsTableViewCell
        cell.backgroundColor = .white
        cell.selectionStyle = .none
        let model = transferVM.transferMethodModel[indexPath.row]
        cell.setUpCell(model)
        if indexPath.row != 2 {
            cell.checkBox.layer.borderColor = UIColor.systemGray4.cgColor
        }
        if indexPath.row == 2 {
            cell.stateLabel.isHidden = false
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        44
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if isCellSelected == false {
            if indexPath.row != 2 {
                let cell = tableView.cellForRow(at: indexPath) as! MethodsTableViewCell
                cell.setIcon(cell.isCellSelected)
                isCellSelected = true
            }
        }
        
        isCellSelected == true ? setButtonState(button: nextButton, isEnabled: true, backgroundColor: selectedButtonColor) : setButtonState(button: nextButton, isEnabled: false, backgroundColor: unselectedButtonColor)
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        if indexPath.row != 2 {
            let cell = tableView.cellForRow(at: indexPath) as! MethodsTableViewCell
            cell.setIcon(cell.isCellSelected)
            isCellSelected = false
        }
    }
}
