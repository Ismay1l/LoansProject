//
//  DocumentsVC.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/19/22.
//

import UIKit

class DocumentsVC: UIViewController {
    
    //MARK: - UI Elements
    private lazy var documentView: DocumentView = {
        let view = DocumentView("Documents to be sign")
        let gesture = UITapGestureRecognizer(target: self, action: #selector(didTapDocument(_:)))
        view.addGestureRecognizer(gesture)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var nextButton: UIButton = {
        let button = UIButton()
        button.setTitle("Next", for: .normal)
        button.backgroundColor = UIColor(red: 0.89, green: 0.89, blue: 0.89, alpha: 1.00)
        button.setTitleColor(UIColor.white, for: .normal)
        button.layer.cornerRadius = 8
        button.addTarget(self, action: #selector(didTapNext(_:)), for: .touchUpInside)
        button.isEnabled = false
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    //MARK: - Parent Delegate
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        setConstraints()
        setBackButton()
    }
    
    //MARK: - Functions
    private func setConstraints() {
        view.addSubview(documentView)
        view.addSubview(nextButton)
        
        NSLayoutConstraint.activate([
            documentView.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor),
            documentView.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor),
            documentView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 25),
            documentView.heightAnchor.constraint(equalToConstant: 45),
            
            nextButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            nextButton.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 16),
            nextButton.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor, constant: -16),
            nextButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    private func setBackButton() {
        let yourBackImage = UIImage(named:"icon-back")
        navigationItem.backButtonTitle = ""
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: yourBackImage, style: .plain, target: self, action: #selector(popToPrevious(_:)))
        navigationController?.navigationBar.tintColor = UIColor(red: 0.22, green: 0.22, blue: 0.22, alpha: 1.00)
        navigationItem.largeTitleDisplayMode = .never
    }
    
    @objc
    private func didTapNext(_ sender: UIButton) {
        let successVC = SuccessVC(state: .success)
        successVC.navigationItem.hidesBackButton = true
        navigationController?.pushViewController(successVC, animated: true)
    }
    
    @objc
    private func didTapDocument(_ sender: UITapGestureRecognizer) {
        nextButton.isEnabled = true
        nextButton.backgroundColor = UIColor(red: 1.00, green: 0.71, blue: 0.00, alpha: 1.00)
    }
    
    @objc
    private func popToPrevious(_ sender: UIBarButtonItem) {
        navigationController?.popViewController(animated: true)
    }
}
