//
//  MethodsTableViewCell.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/14/22.
//

import Foundation
import UIKit

class MethodsTableViewCell: UITableViewCell {
    
    var isCellSelected = false
    
    //MARK: - Parent Delegate
    private lazy var detailLabel: UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.font = .systemFont(ofSize: 16)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    lazy var checkBox: UIImageView = {
        let icon = UIImageView()
        icon.layer.borderWidth = 1
        icon.layer.borderColor = UIColor(red: 0.92, green: 0.93, blue: 0.94, alpha: 1.00).cgColor
        icon.layer.cornerRadius = 10
        icon.translatesAutoresizingMaskIntoConstraints = false
        return icon
    }()
    
    lazy var stateLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 12)
        label.text = "Free"
        label.textColor = UIColor(red: 0.01, green: 0.60, blue: 0.33, alpha: 1.00)
        label.backgroundColor = UIColor(red: 0.93, green: 0.99, blue: 0.95, alpha: 1.00)
        label.layer.cornerRadius = 6
        label.clipsToBounds = true
        label.textAlignment = .center
        label.isHidden = true
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    //MARK: - Parent Delegate
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
    }
    
    //MARK: Functions
    private func setupUI() {
        contentView.addSubview(detailLabel)
        contentView.addSubview(checkBox)
        contentView.addSubview(stateLabel)
        
        NSLayoutConstraint.activate([
            detailLabel.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 16),
            detailLabel.centerYAnchor.constraint(equalTo: self.centerYAnchor),
            
            checkBox.rightAnchor.constraint(equalTo: self.rightAnchor, constant: -16),
            checkBox.centerYAnchor.constraint(equalTo: self.centerYAnchor),
            checkBox.widthAnchor.constraint(equalToConstant: 20),
            checkBox.heightAnchor.constraint(equalToConstant: 20),
            
            stateLabel.rightAnchor.constraint(equalTo: checkBox.leftAnchor, constant: -12),
            stateLabel.centerYAnchor.constraint(equalTo: self.centerYAnchor),
            stateLabel.widthAnchor.constraint(equalToConstant: 33),
            stateLabel.heightAnchor.constraint(equalToConstant: 16)
        ])
    }
    
    func setUpCell(_ model: TransferMethod) {
        detailLabel.text = model.detailText
    }
    
    func setIcon(_ state: Bool) {
        state == true ? unsetCheckbox() : setCheckbox()
    }
    
    private func unsetCheckbox() {
        checkBox.layer.borderWidth = 1
        checkBox.layer.borderColor = UIColor.systemGray4.cgColor
        checkBox.layer.cornerRadius = 10
        checkBox.image = nil
        isCellSelected = false
    }
    
    private func setCheckbox() {
        checkBox.layer.borderWidth = 0
        checkBox.image = UIImage(named: "icon-check")
        isCellSelected = true
    }
}
