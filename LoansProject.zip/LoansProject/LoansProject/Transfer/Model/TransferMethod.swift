//
//  TransferMethod.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/14/22.
//

import Foundation

struct TransferMethod {
    var detailText: String
}
