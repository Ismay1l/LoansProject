//
//  LoansVC.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/6/22.
//

import UIKit

class LoansVC: UIViewController {
    
    //MARK: - Variables
    private let loansVM = LoansVM()
    private var checkCount = 0
    
    //MARK: - UI Elements
    private lazy var loansTableView: UITableView = {
        let view = UITableView()
        view.backgroundColor = .white
        view.scrollsToTop = true
        view.showsVerticalScrollIndicator = false
        view.separatorStyle = .none
        view.isScrollEnabled = true

        view.register(LoansTableViewCell.self, forCellReuseIdentifier: "\(LoansTableViewCell.self)")
        view.dataSource = self
        view.delegate = self
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var nextButton: UIButton = {
        let button = UIButton()
        button.setTitle("Next", for: .normal)
        button.backgroundColor = UIColor(red: 0.89, green: 0.89, blue: 0.89, alpha: 1.00)
        button.setTitleColor(UIColor.white, for: .normal)
        button.layer.cornerRadius = 8
        button.addTarget(self, action: #selector(didTapNext(_:)), for: .touchUpInside)
        button.isEnabled = false
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    //MARK: - Parent Delegate
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        setBackButton()
        setConstraints()
    }
    
    //MARK: - Functions
    private func setBackButton() {
        let yourBackImage = UIImage(named:"icon-back")
        navigationItem.backButtonTitle = ""
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: yourBackImage, style: .plain, target: self, action: #selector(popToPrevious(_:)))
        navigationController?.navigationBar.tintColor = UIColor(red: 0.22, green: 0.22, blue: 0.22, alpha: 1.00)
        navigationItem.largeTitleDisplayMode = .never
    }
    
    private func setConstraints() {
        view.addSubview(loansTableView)
        view.addSubview(nextButton)
        
        NSLayoutConstraint.activate([
            loansTableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            loansTableView.leftAnchor.constraint(equalTo: view.leftAnchor),
            loansTableView.rightAnchor.constraint(equalTo: view.rightAnchor),
            loansTableView.bottomAnchor.constraint(equalTo: nextButton.topAnchor, constant: -20),
            
            nextButton.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 16),
            nextButton.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor, constant: -16),
            nextButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            nextButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    @objc
    private func popToPrevious(_ sender: UIBarButtonItem) {
        navigationController?.popViewController(animated: true)
    }
    
    @objc
    private func didTapNext(_ sender: UIButton) {
        let loanRequestVC = LoanRequestVC()
        loanRequestVC.title = "Loan request"
        navigationController?.pushViewController(loanRequestVC, animated: true)
    }
}

//MARK: - LoansVC Extension
extension LoansVC: UITableViewDelegate,
                   UITableViewDataSource,
                   LoansTableViewCellDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        loansVM.model.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "\(LoansTableViewCell.self)", for: indexPath) as! LoansTableViewCell
        let item = loansVM.model[indexPath.row]
        cell.setUpCell(item)
        cell.selectionStyle = .none
        cell.delegate = self
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        84
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let cell = tableView.cellForRow(at: indexPath) as! LoansTableViewCell
        let checkbox = cell.checkButton
        if checkbox.isSelected {
            checkbox.setBackgroundImage(UIImage(named: "icon-box"), for: .normal)
            checkbox.isSelected = false
            checkCount -= 1
            if checkCount == 0 {
                nextButton.isEnabled = false
                nextButton.backgroundColor = UIColor(red: 0.89, green: 0.89, blue: 0.89, alpha: 1.00)
            }
        } else {
            checkbox.setBackgroundImage(UIImage(named: "icon-checked-box"), for: .normal)
            checkbox.isSelected = true
            checkCount += 1
            nextButton.isEnabled = true
            nextButton.backgroundColor = UIColor(red: 1.00, green: 0.71, blue: 0.00, alpha: 1.00)
        }
    }
    
    func didSelectCheckbox(_ selected: Bool) {
        switch selected {
        case true:
            checkCount += 1
            nextButton.isEnabled = true
            nextButton.backgroundColor = UIColor(red: 1.00, green: 0.71, blue: 0.00, alpha: 1.00)
        case false:
            checkCount -= 1
            if checkCount == 0 {
                nextButton.isEnabled = false
                nextButton.backgroundColor = UIColor(red: 0.89, green: 0.89, blue: 0.89, alpha: 1.00)
            }
        }
    }
}
