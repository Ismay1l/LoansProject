//
//  LoansVC.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/6/22.
//

import UIKit

class LoansVC: UIViewController {
    
    //MARK: - Variables
    private let loansVM = LoansVM()
    private var checkCount = 0
    private var debtAmount: Int = 0
    
    //MARK: - UI Elements
    private lazy var loansTableView: UITableView = {
        let view = UITableView()
        view.backgroundColor = .white
        view.scrollsToTop = true
        view.showsVerticalScrollIndicator = false
        view.separatorStyle = .none
        view.isScrollEnabled = true

        view.register(LoansTableViewCell.self, forCellReuseIdentifier: "\(LoansTableViewCell.self)")
        view.dataSource = self
        view.delegate = self
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var footerLabel = createLabel(textColor: UIColor(red: 0.14, green: 0.12, blue: 0.13, alpha: 1.00), fontSize: 16, fontWeight: .medium)
    private lazy var debtAmountLabel = createLabel(textColor:  UIColor(red: 0.98, green: 0.65, blue: 0.10, alpha: 1.00), fontSize: 16, fontWeight: .medium)
    private lazy var nextButton = createButton(setTitle: "Next", background: unselectedButtonColor, setTitleColor: .white, cornerRadius: 8)
    
    //MARK: - Parent Delegate
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        setBackButton()
        setConstraints()
        setUIElements()
    }
    
    //MARK: - Functions
    private func setBackButton() {
        let yourBackImage = UIImage(named:"icon-back")
        navigationItem.backButtonTitle = ""
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: yourBackImage, style: .plain, target: self, action: #selector(popToPrevious(_:)))
        navigationController?.navigationBar.tintColor = UIColor(red: 0.22, green: 0.22, blue: 0.22, alpha: 1.00)
        navigationItem.largeTitleDisplayMode = .never
    }
    
    private func setUIElements() {
        footerLabel.text = "Total debt to paid: "
        debtAmountLabel.text = "0"
        nextButton.addTarget(self, action: #selector(didTapNext(_:)), for: .touchUpInside)
        nextButton.isEnabled = false
    }
    
    private func setConstraints() {
        view.addSubview(loansTableView)
        view.addSubview(nextButton)
        view.addSubview(footerLabel)
        view.addSubview(debtAmountLabel)
        
        NSLayoutConstraint.activate([
            loansTableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            loansTableView.leftAnchor.constraint(equalTo: view.leftAnchor),
            loansTableView.rightAnchor.constraint(equalTo: view.rightAnchor),
            loansTableView.heightAnchor.constraint(equalToConstant: CGFloat(84 * loansVM.model.count)),
            
            footerLabel.topAnchor.constraint(equalTo: loansTableView.bottomAnchor, constant: 22),
            footerLabel.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 16),
            
            debtAmountLabel.topAnchor.constraint(equalTo: loansTableView.bottomAnchor, constant: 22),
            debtAmountLabel.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor, constant: -16),
            
            nextButton.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 16),
            nextButton.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor, constant: -16),
            nextButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            nextButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    @objc
    private func popToPrevious(_ sender: UIBarButtonItem) {
        navigationController?.popViewController(animated: true)
    }
    
    @objc
    private func didTapNext(_ sender: UIButton) {
        let loanRequestVC = LoanRequestVC(debtAmount)
        loanRequestVC.title = "Loan request"
        navigationController?.pushViewController(loanRequestVC, animated: true)
    }
}

//MARK: - LoansVC Extension
extension LoansVC: UITableViewDelegate,
                   UITableViewDataSource,
                   LoansTableViewCellDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        loansVM.model.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "\(LoansTableViewCell.self)", for: indexPath) as! LoansTableViewCell
        let item = loansVM.model[indexPath.row]
        cell.setUpCell(item)
        cell.selectionStyle = .none
        cell.delegate = self
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        84
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let cell = tableView.cellForRow(at: indexPath) as! LoansTableViewCell
        let checkbox = cell.checkButton
        let amount = cell.amountLabel.text ?? ""
        if checkbox.isSelected {
            performOperation(isAdding: false, amount: amount)
            checkbox.setBackgroundImage(UIImage(named: "icon-box"), for: .normal)
            checkbox.isSelected = false
            checkCount -= 1
            if checkCount == 0 {
                setButtonState(button: nextButton, isEnabled: false, backgroundColor: unselectedButtonColor)
            }
        } else {
            performOperation(isAdding: true, amount: amount)
            checkbox.setBackgroundImage(UIImage(named: "icon-checked-box"), for: .normal)
            checkbox.isSelected = true
            checkCount += 1
            setButtonState(button: nextButton, isEnabled: true, backgroundColor: selectedButtonColor)
        }
    }
    
    func didSelectCheckbox(_ selected: Bool, amount: String) {
        switch selected {
        case true:
            checkCount += 1
            performOperation(isAdding: true, amount: amount)
            setButtonState(button: nextButton, isEnabled: true, backgroundColor: selectedButtonColor)
        case false:
            checkCount -= 1
            performOperation(isAdding: false, amount: amount)
            if checkCount == 0 {
                setButtonState(button: nextButton, isEnabled: false, backgroundColor: unselectedButtonColor)
            }
        }
    }
    
    private func performOperation(isAdding: Bool, amount: String) {
        let debt = Int(debtAmountLabel.text ?? "")
        guard let intAmount = Int(amount) else { return }
        if isAdding {
            debtAmountLabel.text = "\((debt ?? 0) + intAmount)"
        } else {
            debtAmountLabel.text = "\((debt ?? 0) - intAmount)"
        }
        debtAmount = Int(debtAmountLabel.text ?? "") ?? 0
    }
}
