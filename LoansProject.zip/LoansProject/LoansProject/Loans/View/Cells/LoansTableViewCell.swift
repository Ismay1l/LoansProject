//
//  LoansTableViewCell.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/7/22.
//

import Foundation
import UIKit

protocol LoansTableViewCellDelegate: AnyObject {
    func didSelectCheckbox(_ isSelected: Bool, amount: String)
}

class LoansTableViewCell: UITableViewCell {
    
    //MARK: - Variables
    weak var delegate: LoansTableViewCellDelegate?
    
    private let headerLabelTextColor = UIColor(red: 0.14, green: 0.12, blue: 0.13, alpha: 1.00)
    private let dateLabelTextColor = UIColor(red: 0.37, green: 0.39, blue: 0.41, alpha: 1.00)
    
    //MARK: - UI Elements
    private lazy var loanImage: UIImageView = {
        let image = UIImageView()
        image.layer.cornerRadius = 16
        image.translatesAutoresizingMaskIntoConstraints = false
        return image
    }()
    
    private lazy var headerLabel = createLabel(textColor: headerLabelTextColor, fontSize: 16, fontWeight: .regular)
    private lazy var dateLabel = createLabel(textColor: dateLabelTextColor, fontSize: 14, fontWeight: .regular)
    lazy var amountLabel = createLabel(textColor: headerLabelTextColor, fontSize: 16, fontWeight: .regular)
    private lazy var percentageLabel = createLabel(textColor: dateLabelTextColor, fontSize: 14, fontWeight: .regular)
    lazy var checkButton = createButton(setTitle: "", background: .white, setTitleColor: .white, cornerRadius: 0)
    
    //MARK: - Parent Delegate
    required init?(coder: NSCoder) {
        fatalError()
    }

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
        
        checkButton.setBackgroundImage(UIImage(named: "icon-box"), for: UIControl.State.normal)
        checkButton.addTarget(self, action: #selector(didTapCheckbox(_:)), for: .touchUpInside)
    }

    override func prepareForReuse() {
        super.prepareForReuse()
    }

    //MARK: Functions
    private func setupUI() {
        contentView.addSubview(loanImage)
        contentView.addSubview(headerLabel)
        contentView.addSubview(dateLabel)
        contentView.addSubview(amountLabel)
        contentView.addSubview(percentageLabel)
        contentView.addSubview(checkButton)
        
        NSLayoutConstraint.activate([
            loanImage.widthAnchor.constraint(equalToConstant: 60),
            loanImage.heightAnchor.constraint(equalToConstant: 60),
            loanImage.centerYAnchor.constraint(equalTo: self.centerYAnchor),
            loanImage.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 16),
            
            headerLabel.leftAnchor.constraint(equalTo: loanImage.rightAnchor, constant: 18),
            headerLabel.topAnchor.constraint(equalTo: loanImage.topAnchor, constant: 3),
            
            dateLabel.leftAnchor.constraint(equalTo: loanImage.rightAnchor, constant: 18),
            dateLabel.bottomAnchor.constraint(equalTo: loanImage.bottomAnchor, constant: -3),
            
            checkButton.rightAnchor.constraint(equalTo: self.rightAnchor, constant: -16),
            checkButton.centerYAnchor.constraint(equalTo: loanImage.centerYAnchor),
            
            amountLabel.topAnchor.constraint(equalTo: headerLabel.topAnchor),
            amountLabel.rightAnchor.constraint(equalTo: checkButton.leftAnchor, constant: -18),
            
            percentageLabel.bottomAnchor.constraint(equalTo: dateLabel.bottomAnchor),
            percentageLabel.rightAnchor.constraint(equalTo: checkButton.leftAnchor, constant: -18),
        ])
    }
    
    func setUpCell(_ model: Loans) {
        loanImage.image = UIImage(named: model.image)
        headerLabel.text = model.header
        dateLabel.text = model.date
        amountLabel.text = model.amount
        percentageLabel.text = model.percentage
    }
    
    @objc
    private func didTapCheckbox(_ sender: UIButton) {
        sender.isSelected ? setCheckbox(backgroundImage: "icon-box", isBoxSelected: false, amount: amountLabel.text ?? "") : setCheckbox(backgroundImage: "icon-checked-box", isBoxSelected: true, amount: amountLabel.text ?? "")
    }
    
    private func setCheckbox(backgroundImage: String, isBoxSelected: Bool, amount: String) {
        checkButton.setBackgroundImage(UIImage(named: backgroundImage), for: .normal)
        checkButton.isSelected = isBoxSelected
        delegate?.didSelectCheckbox(isBoxSelected, amount: amount)
    }
}

