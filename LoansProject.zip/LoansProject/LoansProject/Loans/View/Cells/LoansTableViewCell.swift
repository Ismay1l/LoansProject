//
//  LoansTableViewCell.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/7/22.
//

import Foundation
import UIKit

protocol LoansTableViewCellDelegate: AnyObject {
    func didSelectCheckbox(_ isSelected: Bool, amount: String)
}

class LoansTableViewCell: UITableViewCell {
    
    //MARK: - Variables
    weak var delegate: LoansTableViewCellDelegate?
    
    //MARK: - UI Elements
    private lazy var loanImage: UIImageView = {
        let image = UIImageView()
        image.layer.cornerRadius = 16
        image.translatesAutoresizingMaskIntoConstraints = false
        return image
    }()
    
    private lazy var headerLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor(red: 0.14, green: 0.12, blue: 0.13, alpha: 1.00)
        label.font = .systemFont(ofSize: 16)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var dateLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor(red: 0.37, green: 0.39, blue: 0.41, alpha: 1.00)
        label.font = .systemFont(ofSize: 14)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    lazy var amountLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor(red: 0.14, green: 0.12, blue: 0.13, alpha: 1.00)
        label.font = .systemFont(ofSize: 16)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var percentageLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor(red: 0.37, green: 0.39, blue: 0.41, alpha: 1.00)
        label.font = .systemFont(ofSize: 14)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    lazy var checkButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setBackgroundImage(UIImage(named: "icon-box"), for: UIControl.State.normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(didTapCheckbox(_:)), for: .touchUpInside)
        return button
    }()
    
    //MARK: - Parent Delegate
    required init?(coder: NSCoder) {
        fatalError()
    }

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }

    override func prepareForReuse() {
        super.prepareForReuse()
    }

    //MARK: Functions
    private func setupUI() {
        contentView.addSubview(loanImage)
        contentView.addSubview(headerLabel)
        contentView.addSubview(dateLabel)
        contentView.addSubview(amountLabel)
        contentView.addSubview(percentageLabel)
        contentView.addSubview(checkButton)
        
        NSLayoutConstraint.activate([
            loanImage.widthAnchor.constraint(equalToConstant: 60),
            loanImage.heightAnchor.constraint(equalToConstant: 60),
            loanImage.centerYAnchor.constraint(equalTo: self.centerYAnchor),
            loanImage.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 16),
            
            headerLabel.leftAnchor.constraint(equalTo: loanImage.rightAnchor, constant: 18),
            headerLabel.topAnchor.constraint(equalTo: loanImage.topAnchor, constant: 3),
            
            dateLabel.leftAnchor.constraint(equalTo: loanImage.rightAnchor, constant: 18),
            dateLabel.bottomAnchor.constraint(equalTo: loanImage.bottomAnchor, constant: -3),
            
            checkButton.rightAnchor.constraint(equalTo: self.rightAnchor, constant: -16),
            checkButton.centerYAnchor.constraint(equalTo: loanImage.centerYAnchor),
            
            amountLabel.topAnchor.constraint(equalTo: headerLabel.topAnchor),
            amountLabel.rightAnchor.constraint(equalTo: checkButton.leftAnchor, constant: -18),
            
            percentageLabel.bottomAnchor.constraint(equalTo: dateLabel.bottomAnchor),
            percentageLabel.rightAnchor.constraint(equalTo: checkButton.leftAnchor, constant: -18),
        ])
    }
    
    func setUpCell(_ model: Loans) {
        loanImage.image = UIImage(named: model.image)
        headerLabel.text = model.header
        dateLabel.text = model.date
        amountLabel.text = model.amount
        percentageLabel.text = model.percentage
    }
    
    @objc
    private func didTapCheckbox(_ sender: UIButton) {
        switch sender.isSelected {
        case true:
            checkButton.setBackgroundImage(UIImage(named: "icon-box"), for: .normal)
            checkButton.isSelected = false
            delegate?.didSelectCheckbox(false, amount: amountLabel.text ?? "")
        case false:
            checkButton.setBackgroundImage(UIImage(named: "icon-checked-box"), for: .normal)
            checkButton.isSelected = true
            delegate?.didSelectCheckbox(true, amount: amountLabel.text ?? "")
        }
    }
}

