//
//  LoansVM.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/7/22.
//

import Foundation

class LoansVM {
    
    var model: [Loans] = [
        Loans(image: "image-loan", header: "Express loan", date: "12 Aug 2021", amount: "1235", percentage: "26%"),
        Loans(image: "image-loan", header: "Express loan 2", date: "16 Aug 2022", amount: "655", percentage: "26%")
    ]
}
