//
//  Loans.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/7/22.
//

import Foundation

struct Loans {
    var image: String
    var header: String
    var date: String
    var amount: String
    var percentage: String
}
