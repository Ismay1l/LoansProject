//
//  UINavigationController.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/12/22.
//

import Foundation
import UIKit

extension UINavigationController {
        
    func backToViewController(viewController: Swift.AnyClass) {
        for element in viewControllers as Array {
            if element.isKind(of: viewController) {
                self.popToViewController(element, animated: true)
                break
            }
        }
    }
}
