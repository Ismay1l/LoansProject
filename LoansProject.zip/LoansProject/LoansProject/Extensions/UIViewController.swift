//
//  UIViewController.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/9/22.
//

import Foundation
import UIKit

extension UIViewController {
    
    func formatDouble(optional: Double?, defaultValue: Double, localizationKey: String) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 2
        
        let unwrappedValue = optional ?? defaultValue
        let number = NSNumber(value: unwrappedValue)
        let formattedValue = formatter.string(from: number)!
        return formattedValue
    }
}
