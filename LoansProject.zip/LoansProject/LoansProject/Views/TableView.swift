//
//  UITableView.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/12/22.
//

import Foundation
import UIKit

class TableView: UIView {
    
    private var informationCount = 6
    
    private lazy var informationTableView: UITableView = {
        let view = UITableView()
        view.backgroundColor = .white
        view.scrollsToTop = true
        view.showsVerticalScrollIndicator = false
        view.separatorStyle = .singleLine
        view.isScrollEnabled = true
        
        view.register(InformationTableViewCell.self, forCellReuseIdentifier: "\(InformationTableViewCell.self)")
        view.dataSource = self
        view.delegate = self
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setConstraints()
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //MARK: - Functions
    private func setConstraints() {
        self.addSubview(informationTableView)
        
        NSLayoutConstraint.activate([
            informationTableView.topAnchor.constraint(equalTo: self.topAnchor),
            informationTableView.leftAnchor.constraint(equalTo: self.leftAnchor),
            informationTableView.bottomAnchor.constraint(equalTo: self.bottomAnchor),
            informationTableView.rightAnchor.constraint(equalTo: self.rightAnchor),
            informationTableView.heightAnchor.constraint(equalToConstant: CGFloat(58 * informationCount)),
        ])
    }
}

extension TableView: UITableViewDataSource,
                       UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return informationCount
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "\(InformationTableViewCell.self)", for: indexPath) as! InformationTableViewCell
        cell.textLabel?.text = "Hiii"
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 58
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        "General information"
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        16
    }
}
