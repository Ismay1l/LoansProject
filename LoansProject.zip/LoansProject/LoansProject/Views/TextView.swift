//
//  UserİnformationView.swift
//  Express24
//
//  Created by Riad Sultanov on 16.05.22.
//  Copyright © 2022 Expressbank. All rights reserved.
//

import UIKit

class TextView: UIView,
                UITextFieldDelegate {
    //    var delegate: FiscalIDValidationDelegate?
    
    lazy var lineView: Bool = true
//    weak var delegate: TextViewDelegate?
    
    lazy var branchStackView: UIStackView = {
        let sv = UIStackView()
        sv.axis  = NSLayoutConstraint.Axis.vertical
        sv.alignment = UIStackView.Alignment.leading
        sv.distribution = UIStackView.Distribution.fillProportionally
        sv.spacing = 4
        sv.translatesAutoresizingMaskIntoConstraints = false;
        return sv
    }()
    
    lazy var brancTitleLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 14)
        label.textColor = UIColor(red: 0.39, green: 0.40, blue: 0.42, alpha: 1.00)
        label.textAlignment = .left
        label.text = ""
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    lazy var brancTextField: UITextField = {
        let tx = UITextField()
        tx.font = .systemFont(ofSize: 14)
        tx.textColor = UIColor(red: 0.22, green: 0.22, blue: 0.22, alpha: 1.00)
        tx.placeholder = ""
        tx.translatesAutoresizingMaskIntoConstraints = false
        return tx
        
    }()
    
    lazy  var errorTitleLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 12)
        label.textColor = UIColor.red
        label.textAlignment = .left
        label.text = ""
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    lazy  var topView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = UIColor(red: 0.85, green: 0.85, blue: 0.85, alpha: 1.00)
        return v
    }()
    lazy var bottomView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = UIColor(red: 0.85, green: 0.85, blue: 0.85, alpha: 1.00)
        return v
    }()
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.setupView()
        self.brancTextField.delegate = self
        self.topView.isHidden = lineView
        self.bottomView.isHidden = lineView
    }
    
    internal func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        performAction()
        return true
    }
    func performAction() {
        endEditing(true)
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField.tag == 0 {
            let maxLength = 7
            let currentString: NSString = textField.text! as NSString
            let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
            
            let allowedCharacters = CharacterSet(charactersIn:"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz").inverted
            
            let components = string.components(separatedBy: allowedCharacters)
            let filtered = components.joined(separator: "")
            
            return newString.length <= maxLength && string == filtered
        }
        
        if textField.tag == 3 {
            //            if let delegate = delegate {
            //                delegate.validateFiscalID()
            //            }
            
            let maxLength = 12
            let currentString: NSString = textField.text! as NSString
            let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
            
            let allowedCharacters = CharacterSet(charactersIn:"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz").inverted
            
            let components = string.components(separatedBy: allowedCharacters)
            let filtered = components.joined(separator: "")
            
            return newString.length <= maxLength && string == filtered
        }
        
        if textField.tag == 2  {
            guard let text = textField.text else { return true }
            
            if  range.length  == 0 && text.count == 0 {
                
                textField.text  = "+994"
                
            }
            
            if  range.length > 0 && range.location == 3   {
                return false
            }
            guard CharacterSet(charactersIn: "1234567890").isSuperset(of: CharacterSet(charactersIn: string)) else {
                return false
            }
            let newLength = text.count + string.count - range.length
            return newLength <= 13
            
        }
        
        if textField.tag == 5  {
            
            let char = string.cString(using: String.Encoding.utf8)!
            let isBackSpace = strcmp(char, "\\b")
            
            if (isBackSpace != -92) {
                do {
                    let regex = try NSRegularExpression(pattern: "^[A-Za-z\\s]+", options: [])
                    if (regex.firstMatch(in: string , options: [], range: NSMakeRange(0, string.count )) == nil) {
                        return false
                    }
                }
                catch {
                    print("")
                }
            }
            return true
        }
        if textField.tag == 6  {
            //            "^[0-9]*((\\.|,)[0-9]{0,2})?$"
            let text = (textField.text ?? "") as NSString
            let newText = text.replacingCharacters(in: range, with: string)
            if let regex = try? NSRegularExpression(pattern:"^[0-9]*((\\.|,)[0-9]{0,2})?$", options: .caseInsensitive) {
                return regex.numberOfMatches(in: newText, options: .reportProgress, range: NSRange(location: 0, length: (newText as NSString).length)) > 0
            }
            
        }
        return true
    }
    
    
    func setupView() {
        addSubview(branchStackView)
        //        addSubview(topView)
        addSubview(bottomView)
        
        branchStackView.addArrangedSubview(brancTitleLabel)
        branchStackView.addArrangedSubview(brancTextField)
        branchStackView.addArrangedSubview(errorTitleLabel)
        errorTitleLabel.isHidden = true
        
        
        NSLayoutConstraint.activate([
            
            //        topView.topAnchor.constraint(equalTo:  topAnchor, constant: 0),
            //        topView.heightAnchor.constraint(equalToConstant:
            //                                            0.5),
            //        topView.leftAnchor.constraint(equalTo:  leftAnchor, constant:0),
            //        topView.rightAnchor.constraint(equalTo: rightAnchor, constant:0),
            
            bottomView.heightAnchor.constraint(equalToConstant:
                                                0.5),
            bottomView.bottomAnchor.constraint(equalTo: bottomAnchor, constant:0),
            bottomView.leftAnchor.constraint(equalTo:  leftAnchor, constant:0),
            bottomView.rightAnchor.constraint(equalTo: rightAnchor, constant:0),
            
            branchStackView.topAnchor.constraint(equalTo: topAnchor, constant: 12),
            branchStackView.leftAnchor.constraint(equalTo: leftAnchor, constant: 16),
            branchStackView.rightAnchor.constraint(equalTo: rightAnchor, constant: -16),
            branchStackView.bottomAnchor.constraint(equalTo: bottomView.topAnchor, constant: -8),
            brancTitleLabel.heightAnchor.constraint(equalToConstant:14),
            brancTextField.widthAnchor.constraint(equalTo: branchStackView.widthAnchor, constant: 0),
            errorTitleLabel.widthAnchor.constraint(equalTo: branchStackView.widthAnchor, constant: 0),
            errorTitleLabel.heightAnchor.constraint(equalToConstant:11),
        ])
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
       
    }
    
   
}


