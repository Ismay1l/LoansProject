//
//  CheckboxView.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/8/22.
//

import UIKit

class CheckboxView: UIView {
    
    //MARK: - UI Elements
    lazy var headerLabel = createLabel(textColor: UIColor(red: 0.37, green: 0.39, blue: 0.41, alpha: 1.00), fontSize: 16, fontWeight: .regular)
    
    lazy var checkbox1: UIButton = {
        let button = UIButton()
        button.setTitleColor(UIColor(red: 0.22, green: 0.22, blue: 0.22, alpha: 1.00), for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    lazy var checkbox1Image: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "icon-box"), for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    lazy var checkbox2: UIButton = {
        let button = UIButton()
        button.setTitleColor(UIColor(red: 0.22, green: 0.22, blue: 0.22, alpha: 1.00), for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    lazy var checkbox2Image: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "icon-box"), for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setConstraints()
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //MARK: - Functions
    private func setConstraints() {
        self.addSubview(headerLabel)
        self.addSubview(checkbox1)
        self.addSubview(checkbox2)
        self.addSubview(checkbox1Image)
        self.addSubview(checkbox2Image)
        
        let screenWidth = UIScreen.main.bounds.size.width
        
        NSLayoutConstraint.activate([
            headerLabel.topAnchor.constraint(equalTo: self.topAnchor),
            headerLabel.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 16),
            
            checkbox1Image.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 16),
            checkbox1Image.topAnchor.constraint(equalTo: headerLabel.bottomAnchor, constant: 16),
            checkbox1Image.widthAnchor.constraint(equalToConstant: 20),
            checkbox1Image.heightAnchor.constraint(equalToConstant: 20),
            
            checkbox1.leftAnchor.constraint(equalTo: checkbox1Image.rightAnchor, constant: 8),
            checkbox1.centerYAnchor.constraint(equalTo: checkbox1Image.centerYAnchor),
            checkbox1.heightAnchor.constraint(equalToConstant: 16),
            
            checkbox2Image.leftAnchor.constraint(equalTo: self.leftAnchor, constant: (screenWidth / 2) + 8),
            checkbox2Image.topAnchor.constraint(equalTo: headerLabel.bottomAnchor, constant: 16),
            checkbox2Image.widthAnchor.constraint(equalToConstant: 20),
            checkbox2Image.heightAnchor.constraint(equalToConstant: 20),
            
            checkbox2.leftAnchor.constraint(equalTo: checkbox2Image.rightAnchor, constant: 8),
            checkbox2.centerYAnchor.constraint(equalTo: checkbox2Image.centerYAnchor),
            checkbox2.heightAnchor.constraint(equalToConstant: 16),
        ])
    }
}
