//
//  ResgisteredVC.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/14/22.
//

import UIKit

enum StateOfRegister {
    case accepted, rejected, success
}

class SuccessVC: UIViewController {
    
    let state: StateOfRegister?
    
    init(state: StateOfRegister) {
        self.state = state
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //MARK: - UI Elements
    private lazy var icon: UIImageView = {
        let icon = UIImageView()
        icon.translatesAutoresizingMaskIntoConstraints = false
        return icon
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.text = "Your request has been registered"
        label.textColor = UIColor(red: 0.22, green: 0.22, blue: 0.22, alpha: 1.00)
        label.font = .systemFont(ofSize: 24, weight: .bold)
        label.textAlignment = .center
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var secondaryLabel: UILabel = {
        let label = UILabel()
        label.text = "We will contact with you. Here you will get information about decision."
        label.textColor = UIColor(red: 0.22, green: 0.22, blue: 0.22, alpha: 1.00)
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.textAlignment = .center
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var buttonStackView: UIStackView = {
        let view = UIStackView()
        view.axis = .vertical
        view.distribution = .equalSpacing
        view.alignment = .leading
        view.isBaselineRelativeArrangement = false
        view.spacing = 16
        view.backgroundColor = .white
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var applyButton: UIButton = {
        let button = UIButton()
        button.setTitle("Apply to the Bank", for: .normal)
        button.backgroundColor = UIColor(red: 1.00, green: 0.71, blue: 0.00, alpha: 1.00)
        button.setTitleColor(UIColor.white, for: .normal)
        button.layer.cornerRadius = 8
        button.addTarget(self, action: #selector(didTapApply(_:)), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private lazy var closeButton: UIButton = {
        let button = UIButton()
        button.setTitle("Close", for: .normal)
        button.backgroundColor = UIColor(red: 1.00, green: 0.71, blue: 0.00, alpha: 1.00)
        button.setTitleColor(UIColor.white, for: .normal)
        button.layer.cornerRadius = 8
        button.addTarget(self, action: #selector(didTapClose(_:)), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    //MARK: - Parent Delegate
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        setState()
        setConstraints()
    }
    
    //MARK: - Functions
    private func setConstraints() {
        view.addSubview(icon)
        view.addSubview(titleLabel)
        view.addSubview(secondaryLabel)
        view.addSubview(buttonStackView)
        
        buttonStackView.addArrangedSubview(applyButton)
        buttonStackView.addArrangedSubview(closeButton)
        
        NSLayoutConstraint.activate([
            icon.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            icon.centerYAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerYAnchor, constant: -80),
            
            titleLabel.topAnchor.constraint(equalTo: icon.bottomAnchor, constant: 32),
            titleLabel.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 60),
            titleLabel.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor, constant: -60),
            
            secondaryLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 12),
            secondaryLabel.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 26),
            secondaryLabel.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor, constant: -26),
            
            buttonStackView.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor),
            buttonStackView.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor),
            buttonStackView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            
            applyButton.heightAnchor.constraint(equalToConstant: 50),
            applyButton.leftAnchor.constraint(equalTo: buttonStackView.leftAnchor, constant: 16),
            applyButton.rightAnchor.constraint(equalTo: buttonStackView.rightAnchor, constant: -16),
            
            closeButton.heightAnchor.constraint(equalToConstant: 50),
            closeButton.leftAnchor.constraint(equalTo: buttonStackView.leftAnchor, constant: 16),
            closeButton.rightAnchor.constraint(equalTo: buttonStackView.rightAnchor, constant: -16)
        ])
    }
    
    private func setState() {
        switch state {
        case .accepted:
            setView(iconName: "icon-calendar-clock", is: true, mainText: "Your request has been registered", secondaryText: "We will contact with you. Here you will get information about decision.", buttonColor: UIColor(red: 1.00, green: 0.71, blue: 0.00, alpha: 1.00))
        case .rejected:
            setView(iconName: "icon-rejection", is: false, mainText: "Rejection", secondaryText: "Your order has been rejected. You can apply to the bank", buttonColor: UIColor(red: 0.96, green: 0.96, blue: 0.96, alpha: 1.00))
            applyButton.backgroundColor = UIColor(red: 1.00, green: 0.71, blue: 0.00, alpha: 1.00)
            closeButton.setTitleColor(UIColor(red: 1.00, green: 0.71, blue: 0.00, alpha: 1.00), for: .normal)
        case .success:
            setSuccessFullyDoneView(iconName: "icon-successful", mainText: "Successful", secondaryText: "Your loan application has been accepted and transferred your card", buttonTitle: "Go to dashboard")
        case .none:
            assertionFailure("There could not be this case!")
        }
    }
    
    private func setSuccessFullyDoneView(iconName: String, mainText: String, secondaryText: String, buttonTitle: String) {
        icon.image = UIImage(named: iconName)
        closeButton.isHidden = true
        titleLabel.text = mainText
        secondaryLabel.text = secondaryText
        applyButton.setTitle(buttonTitle, for: .normal)
    }
    
    private func setView(iconName: String, is buttonHidden: Bool, mainText: String, secondaryText: String, buttonColor: UIColor) {
        icon.image = UIImage(named: iconName)
        applyButton.isHidden = buttonHidden
        titleLabel.text = mainText
        secondaryLabel.text = secondaryText
        closeButton.backgroundColor = buttonColor
    }
    
    @objc
    private func didTapClose(_ sender: UIButton) {
        navigationController?.backToViewController(viewController: HomeVC.self)
    }
    
    @objc
    private func didTapApply(_ sender: UIButton) {
        if state == .success {
            navigationController?.backToViewController(viewController: HomeVC.self)
        }
    }
}
