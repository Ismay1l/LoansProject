//
//  VerificationVC.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/9/22.
//

import Foundation
import UIKit

class VerificationView: UIView {
    // constants
     var lineWidth = CGFloat(6)
    private static let backgroundStrokeColor = UIColor(red: 0.96, green: 0.96, blue: 0.96, alpha: 1.00).cgColor
    private static let defaultForegroundStrokeColor = UIColor.black.cgColor
    
    var iconWidth: Double = 20.0
    var iconHeight: Double = 20.0
    
    // stored properties
    private let foregroundLayer = CAShapeLayer()
    private let backgroundLayer = CAShapeLayer()
    private var layoutSublayersDone = false
    
    private let icon: UIImageView = {
        let view = UIImageView()
//        (frame: CGRect(x: 0, y: 0, width: iconWidth, height: iconHeight))
        view.contentMode = .scaleAspectFit
        view.image = UIImage(named:"image-vector")
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    // computed properties
    private var pathCenter: CGPoint { self.convert(center, from: superview) }
    
    private var radius: CGFloat {
        if frame.width < frame.height {
            return (frame.width - self.lineWidth) / 2.0
        } else {
            return (frame.height - self.lineWidth) / 2.0
        }
    }
    
    // public functions
    func set() {
//        if let id = category.categoryId {
//            icon.sd_setImageRefreshCached(
//                imageURL: "\(Params.BASE_URL_IMAGES)products/cards/thumbnail/\(id).png",
//                placeholderImage: nil
//            )
//        }
        
//        if let colorHex = category.color {
//            foregroundLayer.strokeColor = UIColor(hexString: colorHex).cgColor
//        } else {
            foregroundLayer.strokeColor = Self.defaultForegroundStrokeColor
//        }
        
        foregroundLayer.strokeEnd = CGFloat((60) / 100.0)
    }
    
    
    func sets(percent:Double) {
        self.iconHeight = 35
        self.iconWidth = 35
        foregroundLayer.strokeColor = UIColor(red: 0.98, green: 0.65, blue: 0.10, alpha: 1.00).cgColor
        backgroundLayer.strokeColor = UIColor(red: 1.00, green: 0.96, blue: 0.88, alpha: 1.00).cgColor
        foregroundLayer.strokeEnd = CGFloat((percent) / 100.0)
    }
    
    func getError() {
        foregroundLayer.strokeColor = UIColor(red: 0.93, green: 0.25, blue: 0.11, alpha: 1.00).cgColor
        backgroundLayer.strokeColor = UIColor(red: 1.00, green: 0.85, blue: 0.82, alpha: 1.00).cgColor
        foregroundLayer.strokeEnd = CGFloat((1.0) / 100.0)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupView()
    }
    
    override func layoutSublayers(of layer: CALayer) {
        guard !layoutSublayersDone else { return }
        
        setupView()
        icon.center = pathCenter
        layoutSublayersDone = true
    }
    
    // private functions
    private func drawBackgroundLayer() {
        let path = UIBezierPath(arcCenter: pathCenter, radius: radius, startAngle: 0, endAngle: 2 * CGFloat.pi, clockwise: true)
        
        backgroundLayer.path = path.cgPath
        backgroundLayer.strokeColor = Self.backgroundStrokeColor
        backgroundLayer.lineWidth = self.lineWidth * 0.8
        backgroundLayer.fillColor = UIColor.clear.cgColor
        
        layer.addSublayer(backgroundLayer)
    }
    
    private func drawForegroundLayer() {
        let startAngle = (-CGFloat.pi / 2.0)
        let endAngle = 2.0 * CGFloat.pi + startAngle
        
        let path = UIBezierPath(arcCenter: pathCenter, radius: radius, startAngle: startAngle, endAngle: endAngle, clockwise: true)
        
        foregroundLayer.lineCap = CAShapeLayerLineCap.round
        foregroundLayer.path = path.cgPath
        foregroundLayer.lineWidth = self.lineWidth
        foregroundLayer.fillColor = UIColor.clear.cgColor
        
        layer.addSublayer(foregroundLayer)
    }
    
    private func setupView() {
        layer.sublayers = nil
        drawBackgroundLayer()
        drawForegroundLayer()
        addSubview(icon)
        icon.frame = CGRect(x: 0, y: 0, width: iconWidth, height: iconHeight)
    }
}
