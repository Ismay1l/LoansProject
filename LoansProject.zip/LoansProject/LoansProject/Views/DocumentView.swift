//
//  DocumentView.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/20/22.
//

import UIKit

class DocumentView: UIView {
    
    //MARK: - UI Elements
    private lazy var documentIcon: UIImageView = {
        let icon = UIImageView(image: UIImage(named: "icon-document"))
        icon.translatesAutoresizingMaskIntoConstraints = false
        return icon
    }()
    
    private lazy var documentBackground: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(red: 0.96, green: 0.96, blue: 0.96, alpha: 1.00)
        view.layer.cornerRadius = 10
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    lazy var documentLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor(red: 0.22, green: 0.22, blue: 0.22, alpha: 1.00)
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    init(_ documentLabel: String) {
        super.init(frame: .zero)
        self.documentLabel.text = documentLabel
        
        setConstraints()
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //MARK: - Functions
    private func setConstraints() {
        self.addSubview(documentBackground)
        documentBackground.addSubview(documentIcon)
        self.addSubview(documentLabel)
        
        NSLayoutConstraint.activate([
            documentBackground.topAnchor.constraint(equalTo: self.topAnchor),
            documentBackground.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 16),
            documentBackground.bottomAnchor.constraint(equalTo: self.bottomAnchor),
            documentBackground.widthAnchor.constraint(equalToConstant: 45),
            documentBackground.heightAnchor.constraint(equalToConstant: 45),
            
            documentIcon.centerXAnchor.constraint(equalTo: documentBackground.centerXAnchor),
            documentIcon.centerYAnchor.constraint(equalTo: documentBackground.centerYAnchor),
            
            documentLabel.leftAnchor.constraint(equalTo: documentBackground.rightAnchor, constant: 16),
            documentLabel.centerYAnchor.constraint(equalTo: self.centerYAnchor)
        ])
    }
}
