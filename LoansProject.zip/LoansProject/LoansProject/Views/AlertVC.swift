//
//  AlertVC.swift
//  Express24
//
//  Created by Tural Veliyev on 08.04.22.
//  Copyright © 2022 Expressbank. All rights reserved.
//

import UIKit

protocol CustomAlertDelegate{
    func noButtonPressed()
    func yesButtonPressed()
}


class AlertVC: UIViewController {
    
    var delegate: CustomAlertDelegate?
    
    override var title : String?  {
        didSet {
            
            titleLabel.text = title
        }
    }
    
    var subTitle : String?  {
        didSet {
            
            subtitleLabel.text = subTitle
        }
    }
    
    lazy var yesButton: UIButton = {
        let button = UIButton()
        button.layer.cornerRadius = 10
        button.clipsToBounds = true
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = UIColor(red: 1.00, green: 0.71, blue: 0.00, alpha: 1.00)
        button.addTarget(self, action: #selector(didTapYes(_:)), for: .touchUpInside)
        button.setTitle("Yes", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.isSelected = false
        return button
    }()
    
    lazy var noButton: UIButton = {
        let button = UIButton()
        button.layer.cornerRadius = 10
        button.clipsToBounds = true
        button.setTitleColor(UIColor(red: 1.00, green: 0.71, blue: 0.00, alpha: 1.00), for: .normal)
        button.backgroundColor = UIColor(red: 0.96, green: 0.96, blue: 0.96, alpha: 1.00)
        button.addTarget(self, action: #selector(didTapNo), for: .touchUpInside)
        button.setTitle("No", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.isSelected = false
        return button
    }()
    
    
    lazy var alertView :UIView = {
        var view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 16
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    
    lazy var imageView : UIImageView = {
        var view = UIImageView()
        view.image = UIImage(named: "icon-alert")
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24)
        label.textColor = .gray
        label.textAlignment = .center
        label.text = "Information"
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    lazy var subtitleLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 17)
        label.textColor = .gray
        label.textAlignment = .center
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    @objc
    private func didTapNo() {
        self.delegate?.noButtonPressed()
        removeFromParent()
        self.dismiss(animated: true, completion: nil)
        NotificationCenter.default.post(name: Notification.Name("ReloadData"), object: nil)
    }
    
    @objc
    private func didTapYes(_ sender: UIButton) {
//        self.delegate?.noButtonPressed()
        removeFromParent()
        self.dismiss(animated: true, completion: nil)
        delegate?.yesButtonPressed()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        let gesture = UITapGestureRecognizer(target: self, action:  #selector(self.didTapNo))
        gesture.delegate =  self
        self.view.addGestureRecognizer(gesture)
        self.setUpLayout ()
    }
    
    func setUpLayout () {
        self.view.addSubview(alertView)
        self.alertView.addSubview(imageView)
        self.alertView.addSubview(titleLabel)
        self.alertView.addSubview(subtitleLabel)
        self.alertView.addSubview(yesButton)
        self.alertView.addSubview(noButton)
        
        let offSet = view.frame.size.width - 48
        
        NSLayoutConstraint.activate([
            alertView.heightAnchor.constraint(lessThanOrEqualTo: view.heightAnchor, constant: -50),
            
            alertView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 0),
            alertView.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 24),
            alertView.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -24),
            
            imageView.topAnchor.constraint(equalTo: alertView.topAnchor, constant: 42),
            imageView.heightAnchor.constraint(equalToConstant:
                                                71),
            imageView.centerXAnchor.constraint(equalTo: alertView.centerXAnchor, constant: 0),
            imageView.widthAnchor.constraint(equalToConstant: 79),
            
            titleLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 28),
            titleLabel.leftAnchor.constraint(equalTo: alertView.leftAnchor, constant: 16),
            titleLabel.rightAnchor.constraint(equalTo: alertView.rightAnchor, constant: -16),
            
            subtitleLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 16),
            subtitleLabel.leftAnchor.constraint(equalTo: alertView.leftAnchor, constant: 35),
            subtitleLabel.rightAnchor.constraint(equalTo: alertView.rightAnchor, constant: -35),
            subtitleLabel.bottomAnchor.constraint(equalTo: yesButton.topAnchor, constant: -16),
            
            noButton.leftAnchor.constraint(equalTo: alertView.leftAnchor, constant: 16),
            noButton.rightAnchor.constraint(equalTo: alertView.rightAnchor, constant: -((offSet / 2) + 7.5)),
            noButton.bottomAnchor.constraint(equalTo: alertView.bottomAnchor, constant: -32),
            noButton.heightAnchor.constraint(equalToConstant: 50),
            
            yesButton.leftAnchor.constraint(equalTo: noButton.rightAnchor, constant: 15),
            yesButton.rightAnchor.constraint(equalTo: alertView.rightAnchor, constant:-16),
            yesButton.bottomAnchor.constraint(equalTo: alertView.bottomAnchor, constant: -32),
            yesButton.heightAnchor.constraint(equalToConstant:
                                                50),
        ])
    }
}

extension AlertVC: UIGestureRecognizerDelegate {
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        if touch.view?.isDescendant(of: self.alertView) == true {
            return false
        } else {
            view.endEditing(true)
            return true
        }
    }
}

