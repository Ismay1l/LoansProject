//
//  WarningView.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/13/22.
//

import UIKit

class WarningView: UIView {
    
    //MARK: - UI Elements
    private lazy var warningIcon: UIImageView = {
        let icon = UIImageView(image: UIImage(named: "icon-warning"))
        icon.translatesAutoresizingMaskIntoConstraints = false
        return icon
    }()
    
    private lazy var warningLabel: UILabel = {
        let label = UILabel()
        label.text = "Please write 3 contact numbers"
        label.textColor = .black
        label.font = .systemFont(ofSize: 18)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    //MARK: - Parent Delegate
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setConstraints()
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //MARK: - Functions
    private func setConstraints() {
        self.addSubview(warningIcon)
        self.addSubview(warningLabel)
        
        NSLayoutConstraint.activate([
            warningIcon.leftAnchor.constraint(equalTo: self.leftAnchor),
            warningIcon.centerYAnchor.constraint(equalTo: self.centerYAnchor),
            
            warningLabel.leftAnchor.constraint(equalTo: warningIcon.rightAnchor, constant: 8),
            warningLabel.centerYAnchor.constraint(equalTo: self.centerYAnchor)
        ])
    }
}
