//
//  MainNavigationController.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/6/22.
//

import UIKit

class MainNavigationController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let homeVC = HomeVC()
        homeVC.title = "Cash loan"
        viewControllers = [homeVC]
    }
}
