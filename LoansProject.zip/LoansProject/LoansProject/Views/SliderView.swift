//
//  SliderView.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/7/22.
//

import UIKit

class SliderView: UIView {
    
    //MARK: - Variables
    var stringExtension: String!
    
    //MARK: - UI Elements
    lazy var amountTextLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 14)
        label.textColor = UIColor(red: 0.37, green: 0.39, blue: 0.41, alpha: 1.00)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    lazy var amountLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 18)
        label.textColor = UIColor(red: 0.28, green: 0.30, blue: 0.33, alpha: 1.00)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    lazy var slider: UISlider = {
        let slider = UISlider()
        slider.addTarget(self, action: #selector(didSliderChange(_:)), for: .valueChanged)
        slider.minimumTrackTintColor = UIColor(red: 1.00, green: 0.71, blue: 0.00, alpha: 1.00)
        slider.maximumTrackTintColor = UIColor(red: 0.92, green: 0.92, blue: 0.92, alpha: 1.00)
        slider.setThumbImage(UIImage(named: "icon-thumb"), for: .selected)
        slider.setThumbImage(UIImage(named: "icon-thumb"), for: .normal)
        slider.translatesAutoresizingMaskIntoConstraints = false
        return slider
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setConstraints()
        slider.setNeedsLayout()
        slider.layoutIfNeeded()
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //MARK: - Functions
    private func setConstraints() {
        self.addSubview(amountTextLabel)
        self.addSubview(amountLabel)
        self.addSubview(slider)
        
        NSLayoutConstraint.activate([
            amountTextLabel.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 16),
            amountTextLabel.topAnchor.constraint(equalTo: self.topAnchor),
            
            amountLabel.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 16),
            amountLabel.topAnchor.constraint(equalTo: amountTextLabel.bottomAnchor, constant: 8),
            
            slider.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 3),
            slider.rightAnchor.constraint(equalTo: self.rightAnchor, constant: -3),
            slider.bottomAnchor.constraint(equalTo: self.bottomAnchor),
            slider.topAnchor.constraint(equalTo: amountLabel.bottomAnchor, constant: 12),
            slider.heightAnchor.constraint(equalToConstant: 8)
        ])
    }
    
    @objc
    private func didSliderChange(_ sender: UISlider) {
        if sender.tag == 1 {
            let step: Float = 100
            let value = round(sender.value / step) * step
            amountLabel.text = "\(Int(value)) \(stringExtension ?? "AZN")"
        } else {
            amountLabel.text = "\(Int(sender.value)) \(stringExtension ?? "month")"
        }
    }
}
