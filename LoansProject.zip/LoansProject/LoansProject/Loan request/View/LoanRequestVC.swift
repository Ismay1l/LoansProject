//
//  LoanRequestVC.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/7/22.
//

import UIKit

class LoanRequestVC: UIViewController {
    
    //MARK: - Variables
    private var isIncomeViewEnabled = false
    private var isForceStructureSelected = false
    private var isIncomeSelected = false
    private var isWorkplaceSelected = false
    private var isPensionSelected = false
    
    private var amount: Int = 0
    
    //MARK: - UI Elements
    private lazy var amountSliderView: SliderView = {
        let slider = SliderView()
        slider.amountTextLabel.text = "Amount"
        slider.stringExtension = "AZN"
        slider.slider.minimumValue = Float(amount)
        slider.slider.maximumValue = 30000
        slider.amountLabel.text = "\(amount) AZN"
        slider.slider.tag = 1
        slider.translatesAutoresizingMaskIntoConstraints = false
        return slider
    }()
    
    private lazy var termSliderView: SliderView = {
        let slider = SliderView()
        slider.amountTextLabel.text = "Term"
        slider.stringExtension = "month"
        slider.slider.minimumValue = 3
        slider.slider.maximumValue = 59
        slider.amountLabel.text = "3 month"
        slider.slider.tag = 2
        slider.translatesAutoresizingMaskIntoConstraints = false
        return slider
    }()
    
    private lazy var structureView: CheckboxView = {
        let view = CheckboxView()
        view.headerLabel.text = "Source of sturucture"
        view.checkbox1.setTitle("Other sturucture", for: .normal)
        view.checkbox2.setTitle("Force sturucture", for: .normal)
        view.checkbox1Image.addTarget(self, action: #selector(didTapStructure(_:)), for: .touchUpInside)
        view.checkbox1Image.tag = 5
        view.checkbox1.addTarget(self, action: #selector(didTapStructure(_:)), for: .touchUpInside)
        view.checkbox1.tag = 6
        view.checkbox2Image.addTarget(self, action: #selector(didTapStructure(_:)), for: .touchUpInside)
        view.checkbox2Image.tag = 7
        view.checkbox2.addTarget(self, action: #selector(didTapStructure(_:)), for: .touchUpInside)
        view.checkbox2.tag = 8
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var incomeView: CheckboxView = {
        let view = CheckboxView()
        view.headerLabel.text = "Source of income"
        view.checkbox1.setTitle("Workplace", for: .normal)
        view.checkbox2.setTitle("Pension", for: .normal)
        view.checkbox1Image.setImage(UIImage(named: "icon-unenabled-box"), for: .normal)
        view.checkbox2Image.setImage(UIImage(named: "icon-unenabled-box"), for: .normal)
        view.checkbox1.addTarget(self, action: #selector(didTapIncomeButton(_:)), for: .touchUpInside)
        view.checkbox2.addTarget(self, action: #selector(didTapIncomeButton(_:)), for: .touchUpInside)
        view.checkbox1Image.addTarget(self, action: #selector(didTapIncomeButton(_:)), for: .touchUpInside)
        view.checkbox2Image.addTarget(self, action: #selector(didTapIncomeButton(_:)), for: .touchUpInside)
        view.checkbox1Image.tag = 10
        view.checkbox1.tag = 11
        view.checkbox2Image.tag = 12
        view.checkbox2.tag = 13
        view.checkbox1.isEnabled = false
        view.checkbox2.isEnabled = false
        view.checkbox1Image.isEnabled = false
        view.checkbox2Image.isEnabled = false
        view.isHidden = true
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var nextButton = createButton(setTitle: "Next", background: unselectedButtonColor, setTitleColor: .white, cornerRadius: 8)
    
    init(_ amount: Int) {
        self.amount = amount
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //MARK: - Parent Delegate
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        setBackButton()
        setConstraints()
        nextButton.addTarget(self, action: #selector(didTapNext(_:)), for: .touchUpInside)
        nextButton.isEnabled = false
    }
    
    //MARK: - Functions
    private func setBackButton() {
        let yourBackImage = UIImage(named:"icon-back")
        navigationItem.backButtonTitle = ""
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: yourBackImage, style: .plain, target: self, action: #selector(popToPrevious(_:)))
        navigationController?.navigationBar.tintColor = UIColor(red: 0.22, green: 0.22, blue: 0.22, alpha: 1.00)
        navigationItem.largeTitleDisplayMode = .never
    }
    
    private func setConstraints() {
        view.addSubview(amountSliderView)
        view.addSubview(termSliderView)
        view.addSubview(structureView)
        view.addSubview(incomeView)
        view.addSubview(nextButton)
        
        NSLayoutConstraint.activate([
            amountSliderView.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor),
            amountSliderView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 14),
            amountSliderView.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor),
            amountSliderView.heightAnchor.constraint(equalToConstant: 70),
            
            termSliderView.leftAnchor.constraint(equalTo: view.leftAnchor),
            termSliderView.topAnchor.constraint(equalTo: amountSliderView.bottomAnchor, constant: 20),
            termSliderView.rightAnchor.constraint(equalTo: view.rightAnchor),
            termSliderView.heightAnchor.constraint(equalToConstant: 70),
            
            structureView.topAnchor.constraint(equalTo: termSliderView.bottomAnchor, constant: 42),
            structureView.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor),
            structureView.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor),
            structureView.heightAnchor.constraint(equalToConstant: 50),
            
            incomeView.topAnchor.constraint(equalTo: structureView.bottomAnchor, constant: 35),
            incomeView.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor),
            incomeView.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor),
            incomeView.heightAnchor.constraint(equalToConstant: 50),
            
            nextButton.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 16),
            nextButton.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor, constant: -16),
            nextButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            nextButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    private func enableIncomeView(_ tag: Int) {
        if let button = view.viewWithTag(tag) as? UIButton {
            button.isSelected = true
            button.setImage(UIImage(named: "icon-checked-box"), for: .normal)
            if isIncomeViewEnabled == false {
                incomeView.checkbox1Image.setImage(UIImage(named: "icon-box"), for: .normal)
                incomeView.checkbox2Image.setImage(UIImage(named: "icon-box"), for: .normal)
                isIncomeViewEnabled = true
            }
            incomeView.isHidden = false
            incomeView.checkbox1.isEnabled = true
            incomeView.checkbox2.isEnabled = true
            incomeView.checkbox1Image.isEnabled = true
            incomeView.checkbox2Image.isEnabled = true
        }
    }
    
    private func setCheckboxDefaultIcon(_ tag: Int) {
        if let button = view.viewWithTag(tag) as? UIButton {
            button.isSelected = false
            button.setImage(UIImage(named: "icon-box"), for: .normal)
        }
    }
    
    private func selectIncomeView(_ tag: Int) {
        if let button = view.viewWithTag(tag) as? UIButton {
            button.isSelected = true
            button.setImage(UIImage(named: "icon-checked-box"), for: .normal)
        }
    }
    
    @objc
    private func popToPrevious(_ sender: UIBarButtonItem) {
        navigationController?.popViewController(animated: true)
    }
    
    @objc
    private func didTapNext(_ sender: UIButton) {
        if isForceStructureSelected {
            let registeredVC = SuccessVC(state: .accepted)
            registeredVC.navigationItem.hidesBackButton = true
            navigationController?.pushViewController(registeredVC, animated: true)
        } else {
            let verificationVC = VerificationVC()
            verificationVC.navigationItem.hidesBackButton = true
            navigationController?.pushViewController(verificationVC, animated: true)
        }
    }
    
    @objc
    private func didTapStructure(_ sender: UIButton) {
        let currentButtonTag = sender.tag
        if currentButtonTag == 5 || currentButtonTag == 6 {
            setCheckboxDefaultIcon(7)
            enableIncomeView(5)
            isForceStructureSelected = false
            if isIncomeSelected {
                setButtonState(button: nextButton, isEnabled: true, backgroundColor: selectedButtonColor)
            } else {
                setButtonState(button: nextButton, isEnabled: false, backgroundColor: unselectedButtonColor)
            }
        } else if currentButtonTag == 7 || currentButtonTag == 8 {
            setCheckboxDefaultIcon(5)
            if let button = view.viewWithTag(7) as? UIButton {
                button.isSelected = true
                button.setImage(UIImage(named: "icon-checked-box"), for: .normal)
            }
            isForceStructureSelected = true
            incomeView.isHidden = true
            setButtonState(button: nextButton, isEnabled: true, backgroundColor: selectedButtonColor)
        }
    }
    
    @objc
    private func didTapIncomeButton(_ sender: UIButton) {
        let currentButtonTag = sender.tag
            if currentButtonTag == 10 || currentButtonTag == 11 {
                if isWorkplaceSelected == false {
                    selectIncomeView(10)
                    isWorkplaceSelected = true
                } else {
                    setCheckboxDefaultIcon(10)
                    isWorkplaceSelected = false
                }
            } else if currentButtonTag == 12 || currentButtonTag == 13 {
                if isPensionSelected == false {
                    selectIncomeView(12)
                    isPensionSelected = true
                } else {
                    setCheckboxDefaultIcon(12)
                    isPensionSelected = false
                }
            }
        if isWorkplaceSelected || isPensionSelected {
            setButtonState(button: nextButton, isEnabled: true, backgroundColor: selectedButtonColor)
        } else {
            setButtonState(button: nextButton, isEnabled: false, backgroundColor: unselectedButtonColor)
        }
    }
}
