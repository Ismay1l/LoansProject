//
//  VerificationVC.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/9/22.
//

import UIKit

class VerificationVC: UIViewController {
    
    //MARK: - Variables
    var timer : Timer!
    var second = 0
    var loadingPercent = 0.0
    var flag = false

    //MARK: - UI Elements
    private lazy var verificationView: VerificationView = {
        let view = VerificationView()
        view.sets(percent: 0.0)
        view.lineWidth = 12.0
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var loadingPercentLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor(red: 0.28, green: 0.30, blue: 0.33, alpha: 1.00)
        label.font = .systemFont(ofSize: 14)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var informationLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor(red: 0.28, green: 0.30, blue: 0.33, alpha: 1.00)
        label.font = .systemFont(ofSize: 18)
        label.text = "Please wait, your information is being verified!"
        label.numberOfLines = 0
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    //MARK: - Parent Delegate
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        setConstraints()
        setTimer()
    }
    
    //MARK: - Functions
    private func setTimer() {
        timer = Timer()
        timer = Timer.scheduledTimer(timeInterval:1, target: self, selector: #selector(calculateSeconds), userInfo: nil, repeats: true)
    }
    
    private func setConstraints() {
        view.addSubview(verificationView)
        view.addSubview(loadingPercentLabel)
        view.addSubview(informationLabel)
        
        NSLayoutConstraint.activate([
            verificationView.widthAnchor.constraint(equalToConstant: 160),
            verificationView.heightAnchor.constraint(equalToConstant: 130),
            verificationView.centerYAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerYAnchor),
            verificationView.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            
            loadingPercentLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            loadingPercentLabel.topAnchor.constraint(equalTo: verificationView.bottomAnchor, constant: 18),
            
            informationLabel.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 60),
            informationLabel.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor, constant: -60),
            informationLabel.topAnchor.constraint(equalTo: loadingPercentLabel.bottomAnchor)
        ])
    }
    
    private func startLoadingView() {
        verificationView.sets(percent: loadingPercent)
        let percentage = formatDouble(optional: self.loadingPercent, defaultValue: 0, localizationKey: "loading_percent")
        loadingPercentLabel.text = "Complete \(percentage)% "
    }
    
    @objc
    private func calculateSeconds() {
        print(flag)
        if flag == false {
            second += 8
            loadingPercent += 2.0
            startLoadingView()
        }
        if second == 24 {
            timer.invalidate()
            flag = true
            let loansHomeVC = LoansHomeVC()
            loansHomeVC.title = "Loan request"
            navigationController?.pushViewController(loansHomeVC, animated: true)
        } 
    }
}
