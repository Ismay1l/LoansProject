//
//  General Functions.swift
//  LoansProject
//
//  Created by Ismayil Ismayilov on 12/21/22.
//

import Foundation
import UIKit

func createLabel(textColor: UIColor, fontSize: CGFloat, fontWeight: UIFont.Weight) -> UILabel {
    let label = UILabel()
    label.textColor = textColor
    label.font = .systemFont(ofSize: fontSize)
    label.translatesAutoresizingMaskIntoConstraints = false
    return label
}

func createButton(setTitle: String, background color: UIColor, setTitleColor: UIColor, cornerRadius: CGFloat) -> UIButton {
    let button = UIButton()
    button.setTitle(setTitle, for: .normal)
    button.backgroundColor = color
    button.setTitleColor(setTitleColor, for: .normal)
    button.layer.cornerRadius = cornerRadius
    button.translatesAutoresizingMaskIntoConstraints = false
    return button
}

func setButtonState(button: UIButton, isEnabled: Bool, backgroundColor: UIColor) {
    button.isEnabled = isEnabled
    button.backgroundColor = backgroundColor
}


let unselectedButtonColor = UIColor(red: 0.89, green: 0.89, blue: 0.89, alpha: 1.00)
let selectedButtonColor = UIColor(red: 1.00, green: 0.71, blue: 0.00, alpha: 1.00)
let cancelButtonColor = UIColor(red: 0.96, green: 0.96, blue: 0.96, alpha: 1.00)
